#!/usr/bin/env bash
set -euo pipefail
APP_DIR=/opt/oao-reservoir-bot
install -m 0755 "$APP_DIR/auto_update.sh" /usr/local/bin/oao-reservoir-auto-update
cat > /etc/systemd/system/oao-reservoir-update.service <<'UNIT'
[Unit]
Description=Check GitHub for OAO Reservoir Bot updates
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/oao-reservoir-auto-update
UNIT
cat > /etc/systemd/system/oao-reservoir-update.timer <<'UNIT'
[Unit]
Description=Auto-update OAO Reservoir Bot every 2 minutes

[Timer]
OnBootSec=45s
OnUnitActiveSec=2min
Persistent=true
Unit=oao-reservoir-update.service

[Install]
WantedBy=timers.target
UNIT
systemctl daemon-reload
systemctl enable --now oao-reservoir-update.timer
systemctl start oao-reservoir-update.service || true
systemctl status oao-reservoir-update.timer --no-pager
