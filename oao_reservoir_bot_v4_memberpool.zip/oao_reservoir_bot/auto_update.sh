#!/usr/bin/env bash
set -euo pipefail
APP_DIR=/opt/oao-reservoir-bot
RELEASE_URL='https://github.com/winryelric3245-afk/Res-raid/raw/refs/heads/main/oao_reservoir_bot_v2_deploy_ready.zip'
STATE_FILE="$APP_DIR/.last_release_sha256"
TMP_ZIP=$(mktemp /tmp/oao-rr-release.XXXXXX.zip)
TMP_DIR=$(mktemp -d /tmp/oao-rr-release.XXXXXX)
trap 'rm -f "$TMP_ZIP"; rm -rf "$TMP_DIR"' EXIT

curl -fsSL --connect-timeout 15 --max-time 60 "$RELEASE_URL" -o "$TMP_ZIP"
NEW_SHA=$(sha256sum "$TMP_ZIP" | awk '{print $1}')
OLD_SHA=$(cat "$STATE_FILE" 2>/dev/null || true)
if [[ "$NEW_SHA" == "$OLD_SHA" ]]; then
  exit 0
fi

unzip -q "$TMP_ZIP" -d "$TMP_DIR"
SRC="$TMP_DIR/oao_reservoir_bot"
[[ -f "$SRC/bot.py" && -f "$SRC/requirements.txt" ]] || { echo 'Release missing bot.py/requirements.txt'; exit 1; }
python3 -m py_compile "$SRC/bot.py"

# Keep live secrets and data outside the update payload.
cp -f "$APP_DIR/.env" /tmp/oao-rr-env.bak 2>/dev/null || true
cp -f "$APP_DIR/reservoir.db" /tmp/oao-rr-db.bak 2>/dev/null || true

cp -a "$SRC/." "$APP_DIR/"
[[ -f /tmp/oao-rr-env.bak ]] && mv -f /tmp/oao-rr-env.bak "$APP_DIR/.env"
[[ -f /tmp/oao-rr-db.bak ]] && mv -f /tmp/oao-rr-db.bak "$APP_DIR/reservoir.db"
chmod 600 "$APP_DIR/.env" 2>/dev/null || true

if [[ ! -x "$APP_DIR/.venv/bin/python" ]]; then
  python3 -m venv "$APP_DIR/.venv"
fi
"$APP_DIR/.venv/bin/pip" install -q -r "$APP_DIR/requirements.txt"
"$APP_DIR/.venv/bin/python" -m py_compile "$APP_DIR/bot.py"
printf '%s\n' "$NEW_SHA" > "$STATE_FILE"
systemctl restart oao-reservoir-bot
printf 'OAO Reservoir updated to %s at %s\n' "$NEW_SHA" "$(date -Is)"
