# DigitalOcean deployment

The droplet for this bot is named `oao-reservoir-bot`.

After the project files are copied onto the droplet:

```bash
sudo bash install.sh
sudo nano /opt/oao-reservoir-bot/.env
sudo systemctl restart oao-reservoir-bot
sudo systemctl status oao-reservoir-bot --no-pager
```

Required `.env` values:

```env
DISCORD_TOKEN=your_new_reservoir_bot_token
GUILD_ID=your_discord_server_id
LEADERSHIP_ROLE_IDS=role_id_1,role_id_2
```

Useful logs:

```bash
journalctl -u oao-reservoir-bot -f
```
