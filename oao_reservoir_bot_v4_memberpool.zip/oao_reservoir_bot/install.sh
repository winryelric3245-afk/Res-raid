#!/usr/bin/env bash
set -euo pipefail
APP_DIR=/opt/oao-reservoir-bot
SERVICE=oao-reservoir-bot
if [ "${EUID}" -ne 0 ]; then
  echo "Run as root: sudo bash install.sh"
  exit 1
fi
apt-get update
apt-get install -y python3 python3-venv python3-pip unzip
mkdir -p "$APP_DIR"
cp -a . "$APP_DIR"/
cd "$APP_DIR"
python3 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt
if [ ! -f .env ]; then
  cp .env.example .env
  chmod 600 .env
fi
cat > /etc/systemd/system/${SERVICE}.service <<SERVICEEOF
[Unit]
Description=OAO Reservoir Raid Discord Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${APP_DIR}
EnvironmentFile=${APP_DIR}/.env
ExecStart=${APP_DIR}/.venv/bin/python ${APP_DIR}/bot.py
Restart=always
RestartSec=5
User=root

[Install]
WantedBy=multi-user.target
SERVICEEOF
systemctl daemon-reload
systemctl enable "$SERVICE"
echo
printf 'Installed. Edit %s/.env, then run:\n  systemctl restart %s\n  systemctl status %s --no-pager\n' "$APP_DIR" "$SERVICE" "$SERVICE"
