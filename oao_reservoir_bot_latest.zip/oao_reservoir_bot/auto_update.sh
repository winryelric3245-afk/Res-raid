#!/usr/bin/env bash
set -euo pipefail
APP=/opt/oao-reservoir-bot
URL='https://github.com/winryelric3245-afk/Res-raid/raw/refs/heads/main/oao_reservoir_bot_latest.zip'
STATE="$APP/.last_release_sha256"
ZIP=$(mktemp /tmp/oao-rr.XXXXXX.zip)
DIR=$(mktemp -d /tmp/oao-rr.XXXXXX)
trap 'rm -f "$ZIP"; rm -rf "$DIR"' EXIT
curl -fsSL --connect-timeout 15 --max-time 60 "$URL" -o "$ZIP"
NEW=$(sha256sum "$ZIP"|awk '{print $1}')
OLD=$(cat "$STATE" 2>/dev/null || true)
[[ "$NEW" == "$OLD" ]] && exit 0
unzip -q "$ZIP" -d "$DIR"
SRC="$DIR/oao_reservoir_bot"
[[ -f "$SRC/bot.py" ]] || exit 1
python3 -m py_compile "$SRC/bot.py"
cp -f "$APP/.env" /tmp/oao-env.bak 2>/dev/null || true
cp -f "$APP/reservoir.db" /tmp/oao-db.bak 2>/dev/null || true
cp -a "$SRC/." "$APP/"
[[ -f /tmp/oao-env.bak ]] && mv -f /tmp/oao-env.bak "$APP/.env"
[[ -f /tmp/oao-db.bak ]] && mv -f /tmp/oao-db.bak "$APP/reservoir.db"
chmod 600 "$APP/.env" 2>/dev/null || true
[[ -x "$APP/.venv/bin/python" ]] || python3 -m venv "$APP/.venv"
"$APP/.venv/bin/pip" install -q -r "$APP/requirements.txt"
"$APP/.venv/bin/python" -m py_compile "$APP/bot.py"
printf '%s\n' "$NEW" > "$STATE"
systemctl restart oao-reservoir-bot
