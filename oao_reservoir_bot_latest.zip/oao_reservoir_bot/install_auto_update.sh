#!/usr/bin/env bash
set -euo pipefail
APP=/opt/oao-reservoir-bot
install -m 0755 "$APP/auto_update.sh" /usr/local/bin/oao-reservoir-auto-update
cat >/etc/systemd/system/oao-reservoir-update.service <<'UNIT'
[Unit]
Description=Update OAO Reservoir Bot
After=network-online.target
[Service]
Type=oneshot
ExecStart=/usr/local/bin/oao-reservoir-auto-update
UNIT
cat >/etc/systemd/system/oao-reservoir-update.timer <<'UNIT'
[Unit]
Description=Check OAO Reservoir Bot updates
[Timer]
OnBootSec=1min
OnUnitActiveSec=2min
Persistent=true
[Install]
WantedBy=timers.target
UNIT
systemctl daemon-reload
systemctl enable --now oao-reservoir-update.timer
