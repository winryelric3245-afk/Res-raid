# OAO Reservoir Raid Bot v8

Simple member flow:

1. `/rr`
2. SIGN UP with Tile Survive player name
3. YES / MAYBE / CAN'T GO
4. PP10–PP30
5. Power in 10M steps up to 300M
6. Choose a preferred role
7. Active players JOIN GROUP
8. MY ORDERS shows final building/group, assigned role, and leader

## Member role preferences
Members can choose:
- Reinforcement
- Building Babysitter
- Water Tank
- Roamer

Group Leader is leadership-assigned only. Preferred role and final assigned role are stored separately.

## Groups
Every group is capped at 3 players:
- Central Reservoir
- Treatment Plant 1
- Treatment Plant 2
- Water Process 1
- Water Process 2
- Power Station
- Development Complex
- Ammunition Factory
- Helipad
- Roamer Group

9 building groups x 3 = 27 plus Roamer Group x 3 = 30 Active players.

## Leadership
- ASSIGN PLAYER
- ADD PLAYER
- AUTO ASSIGN
- ASSIGNMENTS
- ROSTER
- GROUPS: lock/unlock self-joining
- SWAP PLAYERS
- LIVE CALL
- RESET RAID

The panel shows NEEDS PLAYERS automatically. Auto Assign uses Power/PP first, then preferred roles as a simple starting layout.

Public live calls auto-clear: normal calls 45 seconds, ALL CENTER 60 seconds. Permanent `/rr` information auto-refreshes instead of reposting.
