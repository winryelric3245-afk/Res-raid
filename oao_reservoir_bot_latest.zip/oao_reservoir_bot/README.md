# OAO Reservoir Raid Bot v13

Discord control bot for OAO Reservoir Raid.

## Signup pool
`/rr` -> **SIGN UP** -> enter Player Name, Power (M), and PP Level -> **Auto Assign Pool**.

Signup has no attendance, preferred-role, group, or building choices. It does not enforce a game PP requirement; PP is used only as part of strength ranking. Leadership or **AUTO ASSIGN** handles all roles and buildings.

The active Auto Assign Pool is capped at 30 players. Leadership can manually move players to Reservist, Maybe, or Can't Go, edit/remove them, or override any assignment.

## Balanced Auto Assign
Strength ranking:

`Power(M) + max(PP - 10, 0) * 5`

The 24 strongest players are spread across the eight important groups rather than stacking the biggest accounts together:
- Central Reservoir
- Roamer Group
- Water Treatment Center #1 / #2
- Water Processing Plant #1 / #2 / #3 / #4

Center retains a slight strength advantage, followed by Roamers, Treatment, then Processing. With a full 30-player pool, the lowest-ranked six are spread across:
- Solar Power Station
- Dev Compound
- Munitions Factory
- Abandoned Helipad

Leadership can change any result after Auto Assign.

## v13 fixes
- AUTO ASSIGN acknowledges Discord immediately before calculations/database work, preventing the mobile "didn't respond in time" error.
- Official 11-building names are used everywhere.
- Old building names are automatically migrated; unknown retired assignments are cleared safely.
- Example player data is removed. On the first v13 launch, legacy player/example records are cleared once so preserved `reservoir.db` files cannot bring sample accounts back.
- Signup is now a single simple modal: Name + Power + PP.
- PP input accepts PP1-PP99 and is not an eligibility requirement.
- The permanent `/rr` panel refreshes automatically when the bot starts.
- RESET RAID clears the current signup/profile pool and assignments cleanly.

## Update
The updater pulls the stable GitHub filename:
`oao_reservoir_bot_latest.zip`
