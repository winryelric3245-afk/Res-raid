# OAO Reservoir Raid Bot v7

Simple Discord workflow:

1. `/rr`
2. SIGN UP with Tile Survive player name
3. YES / MAYBE / CAN'T GO
4. PP10–PP30
5. Power in 10M steps up to 300M
6. Preferred role
7. Active players JOIN GROUP
8. MY ORDERS shows group, role and group leader

## Roles
- Group Leader
- Reinforcement
- Building Babysitter
- Water Tank
- Roamer

## Groups
Every group is capped at 3 players.
- Central Reservoir
- Treatment Plant 1
- Treatment Plant 2
- Water Process 1
- Water Process 2
- Power Station
- Development Complex
- Ammunition Factory
- Helipad
- Roamer Group

9 building groups x 3 = 27 plus Roamer Group x 3 = 30 Active players.

The `/rr` panel auto-refreshes after signup, group, roster, auto-assign, and leadership assignment changes.
