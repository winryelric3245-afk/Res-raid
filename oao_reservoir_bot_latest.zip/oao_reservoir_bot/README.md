# OAO Reservoir Raid Bot v12

Simple Discord control bot for OAO Reservoir Raid.

## Member flow
`/rr` -> SIGN UP -> Player Name -> PP Level -> Power -> Auto Assign Pool

Signup does **not** ask for attendance choice, preferred role, group, or building. A completed signup simply places that player into the 30-player **Auto Assign Pool**. Leadership or AUTO ASSIGN handles the strategy.

Leadership can still manually move players to Reservist, Maybe, or Can't Go, remove them from the current raid, edit them, or assign them manually.

## Auto Assign
Strength ranking uses:

`Power(M) + max(PP - 10, 0) * 5`

The algorithm spreads high-power accounts instead of stacking them.

Priority groups:
1. Central Reservoir
2. Roamer Group
3. Water Treatment Center #1 / #2
4. Water Processing Plant #1 / #2 / #3 / #4
5. Solar Power Station / Dev Compound / Munitions Factory / Abandoned Helipad

For a full 30-player pool:
- 24 strongest players are balanced across Center, Roamers, Treatment, and Processing.
- The lowest-ranked 6 players cover the four secondary buildings.
- Center has the highest target strength, then Roamers, Treatment, then Processing.
- Strong accounts are seeded across important groups before second/third players are added.

Leadership can manually change any role or building after Auto Assign.

## Message cleanup
Temporary selection menus use short timeouts (generally 15 seconds). Temporary confirmations are kept briefly, while the main `/rr` panel remains persistent and auto-updates.

## Update
The updater pulls the stable GitHub filename:
`oao_reservoir_bot_latest.zip`
