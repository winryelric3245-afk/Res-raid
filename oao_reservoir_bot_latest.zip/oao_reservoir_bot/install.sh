#!/usr/bin/env bash
set -euo pipefail
APP=/opt/oao-reservoir-bot
cd "$APP"
python3 -m venv .venv
.venv/bin/pip install -q -U pip
.venv/bin/pip install -q -r requirements.txt
cat >/etc/systemd/system/oao-reservoir-bot.service <<UNIT
[Unit]
Description=OAO Reservoir Raid Discord Bot
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
WorkingDirectory=$APP
ExecStart=$APP/.venv/bin/python $APP/bot.py
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable oao-reservoir-bot
systemctl restart oao-reservoir-bot
