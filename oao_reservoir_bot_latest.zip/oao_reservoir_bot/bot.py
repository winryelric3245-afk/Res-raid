import os
import sqlite3
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / '.env')
TOKEN = os.getenv('DISCORD_TOKEN')
GUILD_ID = int(os.getenv('GUILD_ID', '0') or 0)
LEADERSHIP_ROLE_IDS = {int(x) for x in os.getenv('LEADERSHIP_ROLE_IDS', '').split(',') if x.strip().isdigit()}
DB_PATH = BASE_DIR / 'reservoir.db'
MAP_PATH = BASE_DIR / 'assets' / 'reservoir_map.png'
BOT_VERSION = '12.0-auto-assign-pool'

MAX_ACTIVE = 30
MAX_RESERVISTS = 10
GROUP_SIZE = 3

# Official Reservoir Raid building names from the in-game Buildings screen.
BUILDINGS = [
    'Central Reservoir',
    'Water Treatment Center #1',
    'Water Treatment Center #2',
    'Water Processing Plant #1',
    'Water Processing Plant #2',
    'Water Processing Plant #3',
    'Water Processing Plant #4',
    'Solar Power Station',
    'Dev Compound',
    'Munitions Factory',
    'Abandoned Helipad',
]
ROAMER_GROUP = 'Roamer Group'
GROUPS = BUILDINGS + [ROAMER_GROUP]

# Auto Assign priority based on Alliance Water value and OAO strategy.
# Center is first priority. Roamers are also elite because they react anywhere.
GROUP_PRIORITY = {
    'Central Reservoir': 1,
    ROAMER_GROUP: 1,
    'Water Treatment Center #1': 2,
    'Water Treatment Center #2': 2,
    'Water Processing Plant #1': 3,
    'Water Processing Plant #2': 3,
    'Water Processing Plant #3': 3,
    'Water Processing Plant #4': 3,
    'Solar Power Station': 4,
    'Dev Compound': 4,
    'Munitions Factory': 4,
    'Abandoned Helipad': 4,
}

# Alliance Water values confirmed from the in-game Reservoir Raid Buildings screen.
BUILDING_WATER = {
    'Central Reservoir': (9000, 1800),
    'Water Treatment Center #1': (6000, 1200),
    'Water Treatment Center #2': (6000, 1200),
    'Water Processing Plant #1': (3000, 600),
    'Water Processing Plant #2': (3000, 600),
    'Water Processing Plant #3': (3000, 600),
    'Water Processing Plant #4': (3000, 600),
    'Solar Power Station': (1200, 240),
    'Dev Compound': (1200, 240),
    'Munitions Factory': (1200, 240),
    'Abandoned Helipad': (1200, 240),
}

CORE_GROUPS = [
    'Central Reservoir',
    ROAMER_GROUP,
    'Water Treatment Center #1',
    'Water Treatment Center #2',
    'Water Processing Plant #1',
    'Water Processing Plant #2',
    'Water Processing Plant #3',
    'Water Processing Plant #4',
]
SECONDARY_GROUPS = [
    'Solar Power Station',
    'Dev Compound',
    'Munitions Factory',
    'Abandoned Helipad',
]

# Higher target weight means the balancing algorithm is allowed to keep that
# group somewhat stronger while still spreading big accounts across the map.
AUTO_TARGET_WEIGHT = {
    'Central Reservoir': 1.15,
    ROAMER_GROUP: 1.10,
    'Water Treatment Center #1': 1.05,
    'Water Treatment Center #2': 1.05,
    'Water Processing Plant #1': 1.00,
    'Water Processing Plant #2': 1.00,
    'Water Processing Plant #3': 1.00,
    'Water Processing Plant #4': 1.00,
}

ASSIGNED_ROLES = [
    'Group Leader',
    'Reinforcement',
    'Building Babysitter',
    'Water Tank',
    'Roamer',
]

# Roles are assigned only by leadership or Auto Assign.
# preferred_role remains in the database only for backwards compatibility.

# No example/player roster data is bundled with the bot.
# Players are added only through signup or leadership member management.
MEMBERS = []


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def ensure_col(con, table, col, ddl):
    cols = {r[1] for r in con.execute(f'PRAGMA table_info({table})').fetchall()}
    if col not in cols:
        con.execute(ddl)


def init_db():
    with db() as con:
        con.executescript('''
        CREATE TABLE IF NOT EXISTS alliance_members(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          display_name TEXT NOT NULL COLLATE NOCASE UNIQUE,
          power_m REAL NOT NULL DEFAULT 0,
          plant_level INTEGER NOT NULL DEFAULT 0,
          discord_user_id INTEGER,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS players(
          user_id INTEGER PRIMARY KEY,
          display_name TEXT NOT NULL,
          roster_status TEXT NOT NULL DEFAULT 'active',
          preferred_role TEXT,
          assigned_role TEXT,
          primary_building TEXT,
          power_m REAL NOT NULL DEFAULT 0,
          plant_level INTEGER NOT NULL DEFAULT 0,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS raid_state(
          id INTEGER PRIMARY KEY CHECK(id=1),
          panel_channel_id INTEGER,
          panel_message_id INTEGER
        );
        CREATE TABLE IF NOT EXISTS group_locks(
          group_name TEXT PRIMARY KEY,
          locked INTEGER NOT NULL DEFAULT 0
        );
        INSERT OR IGNORE INTO raid_state(id) VALUES(1);
        ''')
        for col, ddl in {
            'power_m': 'ALTER TABLE players ADD COLUMN power_m REAL NOT NULL DEFAULT 0',
            'plant_level': 'ALTER TABLE players ADD COLUMN plant_level INTEGER NOT NULL DEFAULT 0',
            'preferred_role': 'ALTER TABLE players ADD COLUMN preferred_role TEXT',
            'assigned_role': 'ALTER TABLE players ADD COLUMN assigned_role TEXT',
            'primary_building': 'ALTER TABLE players ADD COLUMN primary_building TEXT',
            'roster_status': "ALTER TABLE players ADD COLUMN roster_status TEXT NOT NULL DEFAULT 'active'",
        }.items():
            ensure_col(con, 'players', col, ddl)
        for col, ddl in {
            'panel_channel_id': 'ALTER TABLE raid_state ADD COLUMN panel_channel_id INTEGER',
            'panel_message_id': 'ALTER TABLE raid_state ADD COLUMN panel_message_id INTEGER',
        }.items():
            ensure_col(con, 'raid_state', col, ddl)
        for n, p, pp in MEMBERS:
            con.execute('INSERT OR IGNORE INTO alliance_members(display_name,power_m,plant_level) VALUES(?,?,?)', (n, p, pp))
        for group in GROUPS:
            con.execute('INSERT OR IGNORE INTO group_locks(group_name,locked) VALUES(?,0)', (group,))


def leadership(member: discord.Member):
    if not isinstance(member, discord.Member):
        return False
    return (
        member.guild_permissions.administrator
        or member.guild_permissions.manage_guild
        or any(r.id in LEADERSHIP_ROLE_IDS for r in member.roles)
    )


def raid_rows(status=None):
    with db() as con:
        if status:
            return con.execute('SELECT * FROM players WHERE roster_status=? ORDER BY power_m DESC, plant_level DESC, display_name COLLATE NOCASE', (status,)).fetchall()
        return con.execute('SELECT * FROM players ORDER BY power_m DESC, plant_level DESC, display_name COLLATE NOCASE').fetchall()


def status_count(status):
    with db() as con:
        return con.execute('SELECT COUNT(*) FROM players WHERE roster_status=?', (status,)).fetchone()[0]


def group_count(group_name):
    with db() as con:
        return con.execute("SELECT COUNT(*) FROM players WHERE roster_status='active' AND primary_building=?", (group_name,)).fetchone()[0]

def group_locked(group_name):
    with db() as con:
        row = con.execute('SELECT locked FROM group_locks WHERE group_name=?', (group_name,)).fetchone()
        return bool(row['locked']) if row else False


def set_group_lock(group_name, locked):
    with db() as con:
        con.execute('INSERT INTO group_locks(group_name,locked) VALUES(?,?) ON CONFLICT(group_name) DO UPDATE SET locked=excluded.locked', (group_name, 1 if locked else 0))


def player_by_discord(user_id):
    with db() as con:
        return con.execute('SELECT * FROM players WHERE user_id=?', (user_id,)).fetchone()


def player_by_name(name):
    with db() as con:
        return con.execute('SELECT * FROM players WHERE display_name=? COLLATE NOCASE', (name,)).fetchone()


def next_manual_user_id():
    # Manual/offline players use negative IDs so they never collide with Discord user IDs.
    with db() as con:
        row = con.execute('SELECT MIN(user_id) FROM players WHERE user_id < 0').fetchone()
        current = row[0] if row and row[0] is not None else 0
        return current - 1 if current < 0 else -1


def manual_add_player(name, power, pp, status='active'):
    name = name.strip()
    if not name:
        return False, 'Player name is required.'
    if player_by_name(name):
        return False, f'**{name}** is already on the raid roster.'
    if power < 0 or power > 300:
        return False, 'Power must be between 0M and 300M.'
    if pp < 10 or pp > 30:
        return False, 'PP level must be between PP10 and PP30.'
    status = status.strip().lower().replace("'", '').replace('’', '')
    aliases = {'active':'active','yes':'active','in':'active','reservist':'reservist','reserve':'reservist','maybe':'maybe','cant':'cant','cant go':'cant','no':'cant'}
    status = aliases.get(status)
    if not status:
        return False, "Status must be Active, Reservist, Maybe, or Can't Go."
    if status == 'active' and status_count('active') >= MAX_ACTIVE:
        return False, 'Active roster is full (30/30). Add them as Reservist or Maybe.'
    if status == 'reservist' and status_count('reservist') >= MAX_RESERVISTS:
        return False, 'Reservists are full (10/10).'
    uid = next_manual_user_id()
    with db() as con:
        con.execute('INSERT INTO alliance_members(display_name,power_m,plant_level) VALUES(?,?,?) ON CONFLICT(display_name) DO UPDATE SET power_m=excluded.power_m,plant_level=excluded.plant_level,updated_at=CURRENT_TIMESTAMP', (name, power, pp))
        con.execute('INSERT INTO players(user_id,display_name,roster_status,power_m,plant_level) VALUES(?,?,?,?,?)', (uid, name, status, power, pp))
    label = "Can't Go" if status == 'cant' else status.title()
    return True, f'Added **{name}** • {int(power)}M • PP{pp} • {label}'


def active_unassigned():
    with db() as con:
        return con.execute("SELECT * FROM players WHERE roster_status='active' AND (primary_building IS NULL OR primary_building='') ORDER BY power_m DESC, plant_level DESC").fetchall()


def upsert_member_profile(user_id, name, power, pp):
    with db() as con:
        linked = con.execute('SELECT * FROM alliance_members WHERE discord_user_id=?', (user_id,)).fetchone()
        named = con.execute('SELECT * FROM alliance_members WHERE display_name=? COLLATE NOCASE', (name,)).fetchone()
        if linked:
            try:
                con.execute('UPDATE alliance_members SET display_name=?,power_m=?,plant_level=?,updated_at=CURRENT_TIMESTAMP WHERE id=?', (name, power, pp, linked['id']))
            except sqlite3.IntegrityError:
                con.execute('UPDATE alliance_members SET power_m=?,plant_level=?,discord_user_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?', (power, pp, user_id, named['id']))
        elif named:
            con.execute('UPDATE alliance_members SET discord_user_id=?,power_m=?,plant_level=?,updated_at=CURRENT_TIMESTAMP WHERE id=?', (user_id, power, pp, named['id']))
        else:
            con.execute('INSERT INTO alliance_members(display_name,power_m,plant_level,discord_user_id) VALUES(?,?,?,?)', (name, power, pp, user_id))


def save_signup(user_id, name, status, power=0, pp=0, preferred_role=None):
    existing = player_by_discord(user_id)
    if status == 'active' and not existing and status_count('active') >= MAX_ACTIVE:
        status = 'reservist'
    if status == 'reservist' and not existing and status_count('reservist') >= MAX_RESERVISTS:
        return False, 'Reservists are full.'
    with db() as con:
        if existing:
            # Changing to maybe/cant clears current group assignment.
            clear_assignment = status not in ('active', 'reservist')
            con.execute('''UPDATE players SET display_name=?,roster_status=?,power_m=?,plant_level=?,preferred_role=?,
                           assigned_role=CASE WHEN ? THEN NULL ELSE assigned_role END,
                           primary_building=CASE WHEN ? THEN NULL ELSE primary_building END,updated_at=CURRENT_TIMESTAMP
                           WHERE user_id=?''',
                        (name, status, power, pp, preferred_role, 1 if clear_assignment else 0, 1 if clear_assignment else 0, user_id))
        else:
            con.execute('INSERT INTO players(user_id,display_name,roster_status,preferred_role,power_m,plant_level) VALUES(?,?,?,?,?,?)',
                        (user_id, name, status, preferred_role, power, pp))
    return True, status


def save_pool_signup(user_id, name, power, pp):
    """Add/update a member in the 30-player Auto Assign Pool.

    Signup does not choose attendance, role, group, or building. The pool is the
    source Auto Assign uses. Leadership can move players to Reservist/Maybe/Can't
    Go later from player management.
    """
    existing = player_by_discord(user_id)
    active_without_self = status_count('active') - (1 if existing and existing['roster_status'] == 'active' else 0)
    if active_without_self >= MAX_ACTIVE:
        return False, 'Auto Assign Pool is full (30/30). Leadership can add you as a Reservist.'
    with db() as con:
        if existing:
            con.execute('''UPDATE players SET display_name=?,roster_status='active',power_m=?,plant_level=?,preferred_role=NULL,
                           assigned_role=CASE WHEN roster_status='active' THEN assigned_role ELSE NULL END,
                           primary_building=CASE WHEN roster_status='active' THEN primary_building ELSE NULL END,
                           updated_at=CURRENT_TIMESTAMP WHERE user_id=?''',
                        (name, power, pp, user_id))
        else:
            con.execute('INSERT INTO players(user_id,display_name,roster_status,power_m,plant_level) VALUES(?,?,?,?,?)',
                        (user_id, name, 'active', power, pp))
    return True, 'active'


def set_group(user_id, group_name):
    r = player_by_discord(user_id)
    if not r or r['roster_status'] != 'active':
        return False, 'You must be on the Active roster to join a group.'
    if group_name not in GROUPS:
        return False, 'Invalid group.'
    if group_locked(group_name):
        return False, f'**{group_name}** is locked by leadership.'
    if r['primary_building'] == group_name:
        return True, f'You are already in **{group_name}**.'
    if group_count(group_name) >= GROUP_SIZE:
        return False, f'**{group_name}** is full (3/3).'
    with db() as con:
        con.execute('UPDATE players SET primary_building=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (group_name, user_id))
    return True, f'Joined **{group_name}**.'


def set_assignment(user_id, group_name, role=None, leadership_override=False):
    if group_name not in GROUPS:
        return False, 'Invalid group.'
    r = player_by_discord(user_id)
    if not r:
        return False, 'Player not found.'
    if r['roster_status'] != 'active':
        return False, 'Player must be Active first.'
    if r['primary_building'] != group_name and group_count(group_name) >= GROUP_SIZE and not leadership_override:
        return False, f'{group_name} is full.'
    # Leadership can move within caps, but never allow >3.
    if r['primary_building'] != group_name and group_count(group_name) >= GROUP_SIZE:
        return False, f'{group_name} is already 3/3.'
    if role and role not in ASSIGNED_ROLES:
        return False, 'Invalid role.'
    with db() as con:
        # One leader per group. Promoting a new leader automatically demotes the old one.
        if role == 'Group Leader':
            con.execute("UPDATE players SET assigned_role='Reinforcement',updated_at=CURRENT_TIMESTAMP WHERE roster_status='active' AND primary_building=? AND assigned_role='Group Leader' AND user_id<>?", (group_name, user_id))
        if role:
            con.execute('UPDATE players SET primary_building=?,assigned_role=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (group_name, role, user_id))
        else:
            con.execute('UPDATE players SET primary_building=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (group_name, user_id))
    return True, 'Assignment saved.'


def change_assigned_role(user_id, role):
    if role not in ASSIGNED_ROLES:
        return False, 'Invalid role.'
    r = player_by_discord(user_id)
    if not r or r['roster_status'] != 'active':
        return False, 'Player must be Active.'
    if not r['primary_building']:
        return False, 'Assign the player to a building/group first.'
    with db() as con:
        if role == 'Group Leader':
            con.execute("UPDATE players SET assigned_role='Reinforcement',updated_at=CURRENT_TIMESTAMP WHERE roster_status='active' AND primary_building=? AND assigned_role='Group Leader' AND user_id<>?", (r['primary_building'], user_id))
        con.execute('UPDATE players SET assigned_role=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (role, user_id))
    return True, f"{r['display_name']} → {role}"


def clear_assignment(user_id):
    r = player_by_discord(user_id)
    if not r:
        return False, 'Player not found.'
    with db() as con:
        con.execute('UPDATE players SET primary_building=NULL,assigned_role=NULL,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (user_id,))
    return True, f"Cleared assignment for {r['display_name']}."


def update_player_stats(user_id, name, power, pp):
    name = name.strip()
    if not name:
        return False, 'Player name is required.'
    if power < 0 or power > 300:
        return False, 'Power must be between 0M and 300M.'
    if pp < 10 or pp > 30:
        return False, 'PP must be between PP10 and PP30.'
    existing = player_by_name(name)
    if existing and existing['user_id'] != user_id:
        return False, 'Another raid player already uses that name.'
    with db() as con:
        con.execute('UPDATE players SET display_name=?,power_m=?,plant_level=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (name, power, pp, user_id))
        con.execute('INSERT INTO alliance_members(display_name,power_m,plant_level) VALUES(?,?,?) ON CONFLICT(display_name) DO UPDATE SET power_m=excluded.power_m,plant_level=excluded.plant_level,updated_at=CURRENT_TIMESTAMP', (name, power, pp))
    return True, f'Updated {name} • {int(power)}M • PP{pp}'


def group_leader(group_name):
    with db() as con:
        return con.execute("SELECT display_name FROM players WHERE roster_status='active' AND primary_building=? AND assigned_role='Group Leader' LIMIT 1", (group_name,)).fetchone()


def strength_score(row):
    """Composite combat score used only for relative Auto Assign ranking.

    Power remains the main input. Each PP level above PP10 contributes a
    5M-equivalent bonus so PP matters without completely overpowering raw power.
    There is no PP eligibility requirement in the bot.
    """
    power = float(row['power_m'] or 0)
    pp = int(row['plant_level'] or 0)
    return power + max(0, pp - 10) * 5


def balanced_priority_order(players):
    """Return players strongest-first by the Power + PP composite score."""
    return sorted(
        players,
        key=lambda r: (strength_score(r), float(r['power_m'] or 0), int(r['plant_level'] or 0)),
        reverse=True,
    )


def build_balanced_auto_assign(players):
    """Build OAO's balanced 30-player Reservoir assignment.

    Design goals:
    - Center is the strongest group overall.
    - Roamers are elite, but not stacked with Center.
    - Treatment is stronger than Processing.
    - Big accounts are spread: seed one strong player into every core group first.
    - The lowest-ranked active accounts cover the four secondary buildings.
    - Team totals are continuously rebalanced after the initial seed.
    """
    ranked = balanced_priority_order(players)[:MAX_ACTIVE]
    buckets = {g: [] for g in GROUPS}
    if not ranked:
        return buckets

    # Reserve up to six lowest-ranked players for low-value secondary coverage
    # when the roster is large enough. With fewer players, high-value core groups
    # are filled first and secondaries may remain open.
    secondary_count = min(6, len(ranked) - 24) if len(ranked) > 24 else 0
    core_players = ranked[:-secondary_count] if secondary_count else ranked
    secondary_players = ranked[-secondary_count:] if secondary_count else []

    # Core capacity is 8 groups x 3 = 24.
    core_players = core_players[:len(CORE_GROUPS) * GROUP_SIZE]

    # Seed one of the strongest accounts into every important group. This is the
    # anti-stacking step: #1 does not get paired immediately with #2 and #3.
    cursor = 0
    for group in CORE_GROUPS:
        if cursor >= len(core_players):
            break
        buckets[group].append(core_players[cursor])
        cursor += 1

    # Remaining strong/mid players go to whichever eligible core group is weakest
    # relative to its target weight. Center/Roamer/Treatment are allowed to finish
    # slightly stronger, but no important group hoards multiple whales by default.
    for player in core_players[cursor:]:
        eligible = [g for g in CORE_GROUPS if len(buckets[g]) < GROUP_SIZE]
        if not eligible:
            break
        def adjusted_total(group):
            total = sum(strength_score(r) for r in buckets[group])
            return total / AUTO_TARGET_WEIGHT[group]
        chosen = min(eligible, key=lambda g: (adjusted_total(g), GROUP_PRIORITY[g], CORE_GROUPS.index(g)))
        buckets[chosen].append(player)

    # Low-power players go to secondary buildings. Give each secondary one player
    # first, then place any extra low-power accounts into the currently weakest
    # secondary team. Manual leadership edits can still take any group up to 3.
    for i, player in enumerate(secondary_players):
        if i < len(SECONDARY_GROUPS):
            chosen = SECONDARY_GROUPS[i]
        else:
            eligible = [g for g in SECONDARY_GROUPS if len(buckets[g]) < 2]
            chosen = min(eligible, key=lambda g: sum(strength_score(r) for r in buckets[g])) if eligible else SECONDARY_GROUPS[i % len(SECONDARY_GROUPS)]
        buckets[chosen].append(player)

    return buckets


def compact_signup_lines(rows, limit=12):
    lines = []
    for r in rows[:limit]:
        group = r['primary_building'] or 'Unassigned'
        role = r['assigned_role'] or 'Unassigned'
        lines.append(f"• **{r['display_name']}** — {int(r['power_m'])}M • PP{r['plant_level']} • {role} • {group}")
    if len(rows) > limit:
        lines.append(f"…and {len(rows)-limit} more")
    return '\n'.join(lines) or 'None'


def home_embed():
    active = raid_rows('active')
    reservists = raid_rows('reservist')
    maybe = raid_rows('maybe')
    cant = raid_rows('cant')
    assigned = sum(1 for r in active if r['primary_building'])
    e = discord.Embed(
        title='OAO RESERVOIR RAID',
        description='**Sign Up → Auto Assign Pool → Leadership assigns → Check My Orders**',
    )
    e.add_field(name='STATUS', value=(
        f'**Auto Assign Pool:** {len(active)}/30\n'
        f'**Reservists:** {len(reservists)}/10\n'
        f'**Maybe:** {len(maybe)}\n'
        f"**Can't Go:** {len(cant)}\n"
        f'**Assigned:** {assigned}/{len(active)}'
    ), inline=True)
    e.add_field(name='GROUPS', value=(
        f'8 priority groups × 3 = 24\n'
        f'Secondary coverage = up to 6\n'
        f'**Pool Max: 30**'
    ), inline=True)
    needs = [f"{g}: {group_count(g)}/3" for g in CORE_GROUPS if group_count(g) < GROUP_SIZE]
    needs += [f"{g}: OPEN" for g in SECONDARY_GROUPS if group_count(g) == 0]
    e.add_field(name='NEEDS PLAYERS', value='\n'.join(needs[:10]) or 'All groups full.', inline=False)
    e.add_field(name='AUTO ASSIGN POOL', value=compact_signup_lines(active, 8)[:1024], inline=False)
    if maybe:
        e.add_field(name=f'MAYBE ({len(maybe)})', value=' • '.join(r['display_name'] for r in maybe)[:1024], inline=False)
    e.set_footer(text=f'v{BOT_VERSION} • Signups and assignments auto-update this panel.')
    return e


def roster_embed():
    e = discord.Embed(title='RAID ROSTER')
    for status, label in [('active', 'AUTO ASSIGN POOL'), ('reservist', 'RESERVISTS'), ('maybe', 'MAYBE'), ('cant', "CAN'T GO")]:
        rows = raid_rows(status)
        text = '\n'.join(f"• {r['display_name']} — {int(r['power_m'])}M • PP{r['plant_level']}" for r in rows) or 'None'
        # Split only if necessary.
        if len(text) <= 1024:
            e.add_field(name=f'{label} ({len(rows)})', value=text, inline=False)
        else:
            chunks = []
            current = ''
            for line in text.splitlines():
                if len(current) + len(line) + 1 > 1000:
                    chunks.append(current)
                    current = line
                else:
                    current += ('\n' if current else '') + line
            if current:
                chunks.append(current)
            for idx, chunk in enumerate(chunks):
                e.add_field(name=f'{label} ({len(rows)})' if idx == 0 else f'{label} continued', value=chunk, inline=False)
    return e


def assignments_embed():
    active = raid_rows('active')
    assigned = sum(1 for r in active if r['primary_building'])
    e = discord.Embed(title='GROUP LEADERS + BUILDING ASSIGNMENTS', description=f'**Active:** {len(active)}/30 • **Assigned:** {assigned}/{len(active)}')
    for group in GROUPS:
        members = [r for r in active if r['primary_building'] == group]
        leader = next((r for r in members if r['assigned_role'] == 'Group Leader'), None)
        lines = [f"**Leader:** {leader['display_name'] if leader else 'OPEN'}"]
        for r in members:
            if leader and r['user_id'] == leader['user_id']:
                continue
            lines.append(f"• {r['display_name']} — {r['assigned_role'] or 'No role'}")
        while len(members) < GROUP_SIZE:
            lines.append('• OPEN')
            members.append(None)
        e.add_field(name=f"{group} ({group_count(group)}/3)", value='\n'.join(lines)[:1024], inline=True)
    unassigned = [r for r in active if not r['primary_building']]
    if unassigned:
        e.add_field(name=f'UNASSIGNED ({len(unassigned)})', value='\n'.join(f"• {r['display_name']} — {r['assigned_role'] or 'No role'}" for r in unassigned)[:1024], inline=False)
    return e


async def save_panel_message(message: discord.Message):
    with db() as con:
        con.execute('UPDATE raid_state SET panel_channel_id=?,panel_message_id=? WHERE id=1', (message.channel.id, message.id))


async def refresh_panel():
    with db() as con:
        s = con.execute('SELECT panel_channel_id,panel_message_id FROM raid_state WHERE id=1').fetchone()
    if not s or not s['panel_channel_id'] or not s['panel_message_id']:
        return
    try:
        channel = bot.get_channel(s['panel_channel_id']) or await bot.fetch_channel(s['panel_channel_id'])
        message = await channel.fetch_message(s['panel_message_id'])
        await message.edit(embed=home_embed(), view=Home())
    except Exception as exc:
        print('Panel refresh skipped:', exc)


class Home(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label='SIGN UP', style=discord.ButtonStyle.success, custom_id='rr_v12_signup', row=0)
    async def signup(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(PlayerNameModal())

    @discord.ui.button(label='MY ORDERS', style=discord.ButtonStyle.primary, custom_id='rr_v8_orders', row=1)
    async def orders(self, interaction: discord.Interaction, button: discord.ui.Button):
        r = player_by_discord(interaction.user.id)
        if not r:
            await interaction.response.send_message('You have not signed up yet.', ephemeral=True)
            return
        leader = group_leader(r['primary_building']) if r['primary_building'] else None
        e = discord.Embed(title='YOUR ORDERS')
        e.description = f"**{r['display_name']}**\nStatus: **{r['roster_status'].replace('_',' ').title()}**"
        e.add_field(name='Assignment', value=(
            f"**Group:** {r['primary_building'] or 'Unassigned'}\n"
            f"**Role:** {r['assigned_role'] or 'Unassigned'}\n"
            f"**Leader:** {leader['display_name'] if leader else 'Unassigned'}"
        ), inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @discord.ui.button(label='ROSTER', style=discord.ButtonStyle.secondary, custom_id='rr_v8_roster', row=1)
    async def roster(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=roster_embed(), ephemeral=True)

    @discord.ui.button(label='ASSIGNMENTS', style=discord.ButtonStyle.secondary, custom_id='rr_v8_assignments', row=2)
    async def assignments(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=assignments_embed(), ephemeral=True)

    @discord.ui.button(label='MAP', style=discord.ButtonStyle.secondary, custom_id='rr_v8_map', row=2)
    async def map_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if MAP_PATH.exists():
            await interaction.response.send_message(file=discord.File(MAP_PATH), ephemeral=True)
        else:
            await interaction.response.send_message('Map file missing.', ephemeral=True)

    @discord.ui.button(label='LEADERSHIP', style=discord.ButtonStyle.danger, custom_id='rr_v8_admin', row=3)
    async def admin(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not leadership(interaction.user):
            await interaction.response.send_message('Leadership only.', ephemeral=True)
            return
        await interaction.response.send_message(embed=discord.Embed(title='RESERVOIR CONTROL', description='Simple setup and live controls.'), view=LeadershipView(), ephemeral=True, delete_after=15)


class PlayerNameModal(discord.ui.Modal, title='Join Auto Assign Pool'):
    player_name = discord.ui.TextInput(label='Tile Survive player name', placeholder='Your in-game name', max_length=40)

    async def on_submit(self, interaction: discord.Interaction):
        name = str(self.player_name).strip()
        if not name:
            await interaction.response.send_message('Enter your Tile Survive player name.', ephemeral=True, delete_after=30)
            return
        await interaction.response.send_message(
            f'Player: **{name}**\nChoose PP level:',
            view=PPView(name),
            ephemeral=True,
            delete_after=30,
        )


class PPView(discord.ui.View):
    def __init__(self, name):
        super().__init__(timeout=15)
        self.add_item(PPSelect(name))


class PPSelect(discord.ui.Select):
    def __init__(self, name):
        self.name = name
        options = [discord.SelectOption(label=f'PP{x}', value=str(x)) for x in range(10, 31)]
        super().__init__(placeholder='Choose PP level', options=options)

    async def callback(self, interaction):
        pp = int(self.values[0])
        await interaction.response.edit_message(content=f'**{self.name} • PP{pp}**\nChoose power range:', view=PowerRangeView(self.name, pp))


class PowerRangeView(discord.ui.View):
    def __init__(self, name, pp):
        super().__init__(timeout=15)
        self.add_item(PowerRangeSelect(name, pp))


class PowerRangeSelect(discord.ui.Select):
    def __init__(self, name, pp):
        self.name = name
        self.pp = pp
        options = [
            discord.SelectOption(label='10M–100M', value='10'),
            discord.SelectOption(label='110M–200M', value='110'),
            discord.SelectOption(label='210M–300M', value='210'),
        ]
        super().__init__(placeholder='Choose power range', options=options)

    async def callback(self, interaction):
        start = int(self.values[0])
        await interaction.response.edit_message(content=f'**{self.name} • PP{self.pp}**\nChoose power:', view=PowerView(self.name, self.pp, start))


class PowerView(discord.ui.View):
    def __init__(self, name, pp, start):
        super().__init__(timeout=15)
        self.add_item(PowerSelect(name, pp, start))


class PowerSelect(discord.ui.Select):
    def __init__(self, name, pp, start):
        self.name = name
        self.pp = pp
        values = list(range(start, min(start + 90, 300) + 1, 10))
        options = [discord.SelectOption(label=f'{x}M', value=str(x)) for x in values]
        super().__init__(placeholder='Power', options=options)

    async def callback(self, interaction):
        power = int(self.values[0])
        upsert_member_profile(interaction.user.id, self.name, power, self.pp)
        ok, final_status = save_pool_signup(interaction.user.id, self.name, power, self.pp)
        if not ok:
            await interaction.response.edit_message(content=final_status, view=None)
            return
        text = (
            f"**ADDED TO AUTO ASSIGN POOL**\n{self.name} • {power}M • PP{self.pp}"
            f"\n\nNo role or building selected. Leadership or **AUTO ASSIGN** will handle assignments."
        )
        await interaction.response.edit_message(content=text, view=None)
        await refresh_panel()


class LeadershipView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=15)

    async def check(self, interaction):
        if not leadership(interaction.user):
            await interaction.response.send_message('Leadership only.', ephemeral=True)
            return False
        return True

    @discord.ui.button(label='ASSIGN PLAYER', style=discord.ButtonStyle.success, row=0)
    async def assign_player(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_message('Pick an Active player:', view=LeadershipPlayerPick(), ephemeral=True, delete_after=20)

    @discord.ui.button(label='ADD PLAYER', style=discord.ButtonStyle.success, row=0)
    async def add_player(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_modal(ManualAddPlayerModal())

    @discord.ui.button(label='FIND PLAYER', style=discord.ButtonStyle.secondary, row=1)
    async def find_player(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_modal(FindPlayerModal())

    @discord.ui.button(label='AUTO ASSIGN', style=discord.ButtonStyle.primary, row=0)
    async def auto_assign(self, interaction, button):
        if not await self.check(interaction): return
        active = raid_rows('active')[:MAX_ACTIVE]
        if not active:
            await interaction.response.send_message('Auto Assign Pool is empty.', ephemeral=True)
            return
        # Balanced Auto Assign: Power + PP ranks players, then spreads high-power
        # accounts across the important groups instead of stacking them together.
        assignments = build_balanced_auto_assign(active)

        with db() as con:
            con.execute("UPDATE players SET primary_building=NULL,assigned_role=NULL,preferred_role=NULL WHERE roster_status='active'")
            for group in GROUPS:
                members = balanced_priority_order(assignments.get(group, []))
                for pos, r in enumerate(members):
                    if pos == 0:
                        role = 'Group Leader'
                    elif group == ROAMER_GROUP:
                        role = 'Water Tank' if pos == 1 else 'Roamer'
                    elif len(members) == 2 and pos == 1:
                        role = 'Building Babysitter'
                    elif pos == 1:
                        role = 'Reinforcement'
                    else:
                        role = 'Building Babysitter'
                    con.execute(
                        'UPDATE players SET primary_building=?,assigned_role=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?',
                        (group, role, r['user_id'])
                    )
        await interaction.response.send_message(
            '**Auto Assign finished.** Big accounts were spread across Center, Roamers, Treatment, and Processing. '
            'Center stays strongest overall, while the lowest-ranked active players cover Solar, Dev, Munitions, and Abandoned Helipad. '
            'Review **ASSIGNMENTS** and adjust manually if needed.',
            ephemeral=True, delete_after=30
        )
        await refresh_panel()

    @discord.ui.button(label='ASSIGNMENTS', style=discord.ButtonStyle.secondary, row=2)
    async def assignments(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_message(embed=assignments_embed(), ephemeral=True)

    @discord.ui.button(label='ROSTER', style=discord.ButtonStyle.secondary, row=2)
    async def roster(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_message(embed=roster_embed(), view=RosterManageView(), ephemeral=True, delete_after=20)

    @discord.ui.button(label='SWAP PLAYERS', style=discord.ButtonStyle.primary, row=3)
    async def swap_players(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_modal(SwapPlayersModal())

    @discord.ui.button(label='LIVE CALL', style=discord.ButtonStyle.danger, row=4)
    async def live_call(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_message('Choose the call:', view=LiveCallView(), ephemeral=True, delete_after=15)

    @discord.ui.button(label='RESET RAID', style=discord.ButtonStyle.danger, row=4)
    async def reset(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_message('Clear this raid signup, roster and assignments? Player database stays saved.', view=ResetView(), ephemeral=True, delete_after=15)


class GroupLockPickView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=15)
        self.add_item(GroupLockSelect())


class GroupLockSelect(discord.ui.Select):
    def __init__(self):
        options = [discord.SelectOption(label=g, value=g, description='LOCKED' if group_locked(g) else 'OPEN') for g in GROUPS]
        super().__init__(placeholder='Choose group', options=options)

    async def callback(self, interaction):
        group = self.values[0]
        await interaction.response.edit_message(content=f'**{group}** is currently **{"LOCKED" if group_locked(group) else "OPEN"}**.', view=GroupLockActionView(group))


class GroupLockActionView(discord.ui.View):
    def __init__(self, group):
        super().__init__(timeout=15)
        self.group = group

    @discord.ui.button(label='LOCK', style=discord.ButtonStyle.danger)
    async def lock(self, interaction, button):
        set_group_lock(self.group, True)
        await interaction.response.edit_message(content=f'**{self.group} locked.** Players cannot self-join it.', view=None)
        await refresh_panel()

    @discord.ui.button(label='UNLOCK', style=discord.ButtonStyle.success)
    async def unlock(self, interaction, button):
        set_group_lock(self.group, False)
        await interaction.response.edit_message(content=f'**{self.group} unlocked.** Players can self-join if space is available.', view=None)
        await refresh_panel()


class FindPlayerModal(discord.ui.Modal, title='Find Player'):
    player_name = discord.ui.TextInput(label='Tile Survive player name', placeholder='Exact or partial name', max_length=40)

    async def on_submit(self, interaction):
        if not leadership(interaction.user):
            await interaction.response.send_message('Leadership only.', ephemeral=True)
            return
        term = str(self.player_name).strip()
        with db() as con:
            rows = con.execute("SELECT * FROM players WHERE display_name LIKE ? COLLATE NOCASE ORDER BY roster_status='active' DESC,power_m DESC LIMIT 10", (f'%{term}%',)).fetchall()
        if not rows:
            await interaction.response.send_message('No raid player found with that name.', ephemeral=True, delete_after=30)
            return
        if len(rows) == 1:
            r = rows[0]
            await interaction.response.send_message(
                f"**{r['display_name']}** • {int(r['power_m'])}M • PP{r['plant_level']}\nBuilding: **{r['primary_building'] or 'Unassigned'}** • Role: **{r['assigned_role'] or 'Unassigned'}**",
                view=PlayerManageView(r['user_id']), ephemeral=True, delete_after=20)
            return
        await interaction.response.send_message('Choose player:', view=SearchResultsView(rows), ephemeral=True, delete_after=20)


class SearchResultsView(discord.ui.View):
    def __init__(self, rows):
        super().__init__(timeout=20)
        self.add_item(SearchResultsSelect(rows))


class SearchResultsSelect(discord.ui.Select):
    def __init__(self, rows):
        opts=[discord.SelectOption(label=r['display_name'][:100], description=f"{r['roster_status'].title()} • {int(r['power_m'])}M • PP{r['plant_level']}", value=str(r['user_id'])) for r in rows[:25]]
        super().__init__(placeholder='Choose player', options=opts)

    async def callback(self, interaction):
        r=player_by_discord(int(self.values[0]))
        await interaction.response.edit_message(
            content=f"**{r['display_name']}** • {int(r['power_m'])}M • PP{r['plant_level']}\nStatus: **{r['roster_status'].title()}**\nBuilding: **{r['primary_building'] or 'Unassigned'}**\nRole: **{r['assigned_role'] or 'Unassigned'}**",
            view=PlayerManageView(r['user_id']))


class SwapPlayersModal(discord.ui.Modal, title='Swap Players'):
    player_a = discord.ui.TextInput(label='Player A', placeholder='Exact Tile Survive name', max_length=40)
    player_b = discord.ui.TextInput(label='Player B', placeholder='Exact Tile Survive name', max_length=40)

    async def on_submit(self, interaction):
        if not leadership(interaction.user):
            await interaction.response.send_message('Leadership only.', ephemeral=True)
            return
        a = player_by_name(str(self.player_a).strip())
        b = player_by_name(str(self.player_b).strip())
        if not a or not b:
            await interaction.response.send_message('Both players must be on the current raid roster. Check the names and try again.', ephemeral=True)
            return
        if a['roster_status'] != 'active' or b['roster_status'] != 'active':
            await interaction.response.send_message('Both players must be Active to swap assignments.', ephemeral=True)
            return
        with db() as con:
            con.execute('UPDATE players SET primary_building=?,assigned_role=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (b['primary_building'], b['assigned_role'], a['user_id']))
            con.execute('UPDATE players SET primary_building=?,assigned_role=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (a['primary_building'], a['assigned_role'], b['user_id']))
        await interaction.response.send_message(f"Swapped **{a['display_name']}** and **{b['display_name']}**.", ephemeral=True)
        await refresh_panel()


class ManualAddPlayerModal(discord.ui.Modal, title='Add Player'):
    player_name = discord.ui.TextInput(label='Tile Survive player name', placeholder='In-game name', max_length=40)
    power = discord.ui.TextInput(label='Power (millions)', placeholder='Example: 150', max_length=6)
    pp = discord.ui.TextInput(label='PP Level', placeholder='10-30', max_length=2)
    status = discord.ui.TextInput(label='Status', placeholder="Active / Reservist / Maybe / Can't Go", default='Active', max_length=20)

    async def on_submit(self, interaction):
        if not leadership(interaction.user):
            await interaction.response.send_message('Leadership only.', ephemeral=True)
            return
        try:
            power = float(str(self.power).strip().replace('M','').replace('m',''))
            pp = int(str(self.pp).strip().upper().replace('PP',''))
        except ValueError:
            await interaction.response.send_message('Use numbers for Power and PP. Example: **150** and **27**.', ephemeral=True)
            return
        ok, msg = manual_add_player(str(self.player_name), power, pp, str(self.status))
        await interaction.response.send_message(msg, ephemeral=True)
        if ok:
            await refresh_panel()


class LeadershipPlayerPick(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=20)
        self.add_item(LeadershipPlayerSelect())


class LeadershipPlayerSelect(discord.ui.Select):
    def __init__(self):
        rows = raid_rows('active')[:25]
        options = [discord.SelectOption(label=r['display_name'][:100], description=f"{int(r['power_m'])}M • PP{r['plant_level']}", value=str(r['user_id'])) for r in rows]
        if not options:
            options = [discord.SelectOption(label='No Active players', value='0')]
        super().__init__(placeholder='Choose player', options=options)

    async def callback(self, interaction):
        uid = int(self.values[0])
        if uid == 0:
            await interaction.response.edit_message(content='No Active players.', view=None)
            return
        r = player_by_discord(uid)
        await interaction.response.edit_message(
            content=(f"**{r['display_name']}** • {int(r['power_m'])}M • PP{r['plant_level']}\n"
                     f"Status: **{r['roster_status'].title()}**\n"
                     f"Building: **{r['primary_building'] or 'Unassigned'}**\n"
                     f"Role: **{r['assigned_role'] or 'Unassigned'}**"),
            view=PlayerManageView(uid)
        )


class PlayerManageView(discord.ui.View):
    def __init__(self, uid):
        super().__init__(timeout=20)
        self.uid = uid

    @discord.ui.button(label='CHANGE ROLE', style=discord.ButtonStyle.primary, row=0)
    async def change_role(self, interaction, button):
        r = player_by_discord(self.uid)
        if not r or not r['primary_building']:
            await interaction.response.edit_message(content='Assign this player to a building/group first.', view=self)
            return
        await interaction.response.edit_message(content=f"Change **{r['display_name']}** role:", view=ChangeRoleView(self.uid))

    @discord.ui.button(label='CHANGE BUILDING', style=discord.ButtonStyle.success, row=0)
    async def change_building(self, interaction, button):
        r = player_by_discord(self.uid)
        role = r['assigned_role'] if r and r['assigned_role'] in ASSIGNED_ROLES else 'Reinforcement'
        await interaction.response.edit_message(content=f"Move **{r['display_name']}** to:", view=QuickAssignButtons(self.uid, role))

    @discord.ui.button(label='FULL ASSIGN', style=discord.ButtonStyle.success, row=0)
    async def full_assign(self, interaction, button):
        await interaction.response.edit_message(content='Choose role:', view=LeadershipRolePick(self.uid))

    @discord.ui.button(label='CLEAR ASSIGNMENT', style=discord.ButtonStyle.secondary, row=1)
    async def clear(self, interaction, button):
        ok, msg = clear_assignment(self.uid)
        await interaction.response.edit_message(content=msg, view=None)
        if ok: await refresh_panel()

    @discord.ui.button(label='EDIT PLAYER', style=discord.ButtonStyle.secondary, row=1)
    async def edit(self, interaction, button):
        await interaction.response.send_modal(EditPlayerModal(self.uid))

    @discord.ui.button(label='ROSTER STATUS', style=discord.ButtonStyle.secondary, row=1)
    async def roster_status(self, interaction, button):
        await interaction.response.edit_message(content='Choose roster status:', view=RosterStatusButtons(self.uid))


class ChangeRoleView(discord.ui.View):
    def __init__(self, uid):
        super().__init__(timeout=15)
        self.uid = uid
        self.add_item(ChangeRoleSelect(uid))


class ChangeRoleSelect(discord.ui.Select):
    def __init__(self, uid):
        self.uid = uid
        super().__init__(placeholder='Choose new role', options=[discord.SelectOption(label=r) for r in ASSIGNED_ROLES])

    async def callback(self, interaction):
        ok, msg = change_assigned_role(self.uid, self.values[0])
        await interaction.response.edit_message(content=f'**{msg}**' if ok else msg, view=None)
        if ok: await refresh_panel()


class EditPlayerModal(discord.ui.Modal, title='Edit Player'):
    def __init__(self, uid):
        super().__init__()
        self.uid = uid
        r = player_by_discord(uid)
        self.name_input = discord.ui.TextInput(label='Tile Survive name', default=(r['display_name'] if r else ''), max_length=40)
        self.power_input = discord.ui.TextInput(label='Power (millions)', default=(str(int(r['power_m'])) if r else '0'), max_length=6)
        self.pp_input = discord.ui.TextInput(label='PP Level', default=(str(r['plant_level']) if r else '10'), max_length=2)
        self.add_item(self.name_input)
        self.add_item(self.power_input)
        self.add_item(self.pp_input)

    async def on_submit(self, interaction):
        try:
            power = float(str(self.power_input).strip().replace('M','').replace('m',''))
            pp = int(str(self.pp_input).strip().upper().replace('PP',''))
        except ValueError:
            await interaction.response.send_message('Use numbers for Power and PP.', ephemeral=True, delete_after=30)
            return
        ok, msg = update_player_stats(self.uid, str(self.name_input), power, pp)
        await interaction.response.send_message(msg, ephemeral=True, delete_after=30)
        if ok: await refresh_panel()


class LeadershipRolePick(discord.ui.View):
    def __init__(self, uid):
        super().__init__(timeout=15)
        self.add_item(LeadershipRoleSelect(uid))


class LeadershipRoleSelect(discord.ui.Select):
    def __init__(self, uid):
        self.uid = uid
        super().__init__(placeholder='Choose role', options=[discord.SelectOption(label=r) for r in ASSIGNED_ROLES])

    async def callback(self, interaction):
        role = self.values[0]
        await interaction.response.edit_message(content=f'Role: **{role}**\nTap the group/building:', view=QuickAssignButtons(self.uid, role))


class QuickAssignButtons(discord.ui.View):
    def __init__(self, uid, role):
        super().__init__(timeout=15)
        self.uid = uid
        self.role = role
        labels = [
            ('CENTER', 'Central Reservoir'),
            ('TREAT 1', 'Water Treatment Center #1'),
            ('TREAT 2', 'Water Treatment Center #2'),
            ('PROCESS 1', 'Water Processing Plant #1'),
            ('PROCESS 2', 'Water Processing Plant #2'),
            ('PROCESS 3', 'Water Processing Plant #3'),
            ('PROCESS 4', 'Water Processing Plant #4'),
            ('POWER', 'Solar Power Station'),
            ('DEVELOP', 'Dev Compound'),
            ('AMMO', 'Munitions Factory'),
            ('HELIPAD', 'Abandoned Helipad'),
            ('ROAMERS', ROAMER_GROUP),
        ]
        for idx, (label, group) in enumerate(labels):
            button = discord.ui.Button(label=label, style=discord.ButtonStyle.primary, row=idx // 5)
            async def callback(interaction, group=group):
                ok, msg = set_assignment(self.uid, group, self.role, leadership_override=True)
                if ok:
                    r = player_by_discord(self.uid)
                    msg = f"**{r['display_name']} → {group} → {self.role}**"
                await interaction.response.edit_message(content=msg, view=None)
                if ok:
                    await refresh_panel()
            button.callback = callback
            self.add_item(button)


class RosterManageView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=20)
        self.add_item(RosterPlayerSelect())


class RosterPlayerSelect(discord.ui.Select):
    def __init__(self):
        rows = raid_rows()[:25]
        options = [discord.SelectOption(label=r['display_name'][:100], description=r['roster_status'].title(), value=str(r['user_id'])) for r in rows]
        if not options:
            options = [discord.SelectOption(label='No signups', value='0')]
        super().__init__(placeholder='Move a player', options=options)

    async def callback(self, interaction):
        uid = int(self.values[0])
        if uid == 0:
            await interaction.response.edit_message(content='No signups yet.', view=None)
            return
        await interaction.response.edit_message(content='Choose roster status:', view=RosterStatusButtons(uid))


class RosterStatusButtons(discord.ui.View):
    def __init__(self, uid):
        super().__init__(timeout=15)
        self.uid = uid

    async def move(self, interaction, status):
        r = player_by_discord(self.uid)
        if not r:
            await interaction.response.edit_message(content='Player not found.', view=None)
            return
        if status == 'active' and r['roster_status'] != 'active' and status_count('active') >= MAX_ACTIVE:
            await interaction.response.edit_message(content='Active roster is full (30/30).', view=None)
            return
        if status == 'reservist' and r['roster_status'] != 'reservist' and status_count('reservist') >= MAX_RESERVISTS:
            await interaction.response.edit_message(content='Reservists are full (10/10).', view=None)
            return
        with db() as con:
            con.execute("UPDATE players SET roster_status=?,primary_building=CASE WHEN ? IN ('maybe','cant','reservist') THEN NULL ELSE primary_building END,assigned_role=CASE WHEN ? IN ('maybe','cant','reservist') THEN NULL ELSE assigned_role END,updated_at=CURRENT_TIMESTAMP WHERE user_id=?", (status, status, status, self.uid))
        await interaction.response.edit_message(content=f"**{r['display_name']} → {status.replace('_',' ').title()}**", view=None)
        await refresh_panel()

    @discord.ui.button(label='ACTIVE', style=discord.ButtonStyle.success)
    async def active(self, interaction, button): await self.move(interaction, 'active')
    @discord.ui.button(label='RESERVIST', style=discord.ButtonStyle.primary)
    async def reservist(self, interaction, button): await self.move(interaction, 'reservist')
    @discord.ui.button(label='MAYBE', style=discord.ButtonStyle.secondary)
    async def maybe(self, interaction, button): await self.move(interaction, 'maybe')
    @discord.ui.button(label="CAN'T GO", style=discord.ButtonStyle.danger)
    async def cant(self, interaction, button): await self.move(interaction, 'cant')


class LiveCallView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=15)

    async def choose(self, interaction, action):
        await interaction.response.edit_message(content=f'**{action}** — choose group/building:', view=LiveGroupSelectView(action))

    @discord.ui.button(label='PUSH', style=discord.ButtonStyle.danger)
    async def push(self, i, b): await self.choose(i, 'PUSH')
    @discord.ui.button(label='REINFORCE', style=discord.ButtonStyle.success)
    async def reinforce(self, i, b): await self.choose(i, 'REINFORCE')
    @discord.ui.button(label='HOLD', style=discord.ButtonStyle.primary)
    async def hold(self, i, b): await self.choose(i, 'HOLD')
    @discord.ui.button(label='ROTATE', style=discord.ButtonStyle.secondary)
    async def rotate(self, i, b): await self.choose(i, 'ROTATE')
    @discord.ui.button(label='WATER TANK', style=discord.ButtonStyle.secondary)
    async def tank(self, i, b):
        await i.response.send_message('**OAO CALL — WATER TANK**\nWater Tank players move now. Everyone else hold assignments.', allowed_mentions=discord.AllowedMentions.none(), delete_after=45)
    @discord.ui.button(label='ALL CENTER', style=discord.ButtonStyle.danger)
    async def center(self, i, b):
        await i.response.send_message('**OAO CALL — ALL CENTER**\nAll available Reinforcement and Roamer players move to **Central Reservoir**.', allowed_mentions=discord.AllowedMentions.none(), delete_after=60)


class LiveGroupSelectView(discord.ui.View):
    def __init__(self, action):
        super().__init__(timeout=15)
        self.add_item(LiveGroupSelect(action))


class LiveGroupSelect(discord.ui.Select):
    def __init__(self, action):
        self.action = action
        super().__init__(placeholder='Choose group/building', options=[discord.SelectOption(label=g) for g in GROUPS])

    async def callback(self, interaction):
        group = self.values[0]
        await interaction.response.send_message(f'**OAO CALL — {self.action} {group.upper()}**\nAssigned group executes. Everyone else holds.', allowed_mentions=discord.AllowedMentions.none(), delete_after=45)


class ResetView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=15)

    @discord.ui.button(label='YES, RESET', style=discord.ButtonStyle.danger)
    async def yes(self, interaction, button):
        with db() as con:
            con.execute('DELETE FROM players')
            con.execute('UPDATE group_locks SET locked=0')
        await interaction.response.edit_message(content='Raid reset. OAO player database was kept.', view=None)
        await refresh_panel()

    @discord.ui.button(label='CANCEL', style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction, button):
        await interaction.response.edit_message(content='Cancelled.', view=None)


intents = discord.Intents.default()
bot = commands.Bot(command_prefix='!', intents=intents)


@bot.event
async def on_ready():
    bot.add_view(Home())
    if GUILD_ID:
        guild = discord.Object(id=GUILD_ID)
        try:
            bot.tree.copy_global_to(guild=guild)
            await bot.tree.sync(guild=guild)
        except Exception as exc:
            print('Guild sync failed:', exc)
    else:
        try:
            await bot.tree.sync()
        except Exception as exc:
            print('Global sync failed:', exc)
    print(f'Logged in as {bot.user} | OAO RR {BOT_VERSION}')


@bot.tree.command(name='rr', description='Open the OAO Reservoir Raid panel')
async def rr(interaction: discord.Interaction):
    await interaction.response.send_message(embed=home_embed(), view=Home())
    message = await interaction.original_response()
    await save_panel_message(message)


@bot.tree.command(name='rr_assignments', description='Show group leaders and building assignments')
async def rr_assignments(interaction: discord.Interaction):
    await interaction.response.send_message(embed=assignments_embed(), ephemeral=True)


@bot.tree.command(name='rr_roster', description='Show Reservoir signup roster')
async def rr_roster(interaction: discord.Interaction):
    await interaction.response.send_message(embed=roster_embed(), ephemeral=True)


init_db()
if not TOKEN:
    raise RuntimeError('DISCORD_TOKEN is missing from .env')
bot.run(TOKEN)
