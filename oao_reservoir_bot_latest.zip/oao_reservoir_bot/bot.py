import os
import sqlite3
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / '.env')
TOKEN = os.getenv('DISCORD_TOKEN')
GUILD_ID = int(os.getenv('GUILD_ID', '0') or 0)
LEADERSHIP_ROLE_IDS = {int(x) for x in os.getenv('LEADERSHIP_ROLE_IDS', '').split(',') if x.strip().isdigit()}
DB_PATH = BASE_DIR / 'reservoir.db'
MAP_PATH = BASE_DIR / 'assets' / 'reservoir_map.png'
BOT_VERSION = '9.0-player-controls'

MAX_ACTIVE = 30
MAX_RESERVISTS = 10
GROUP_SIZE = 3

# Only the confirmed Reservoir buildings.
BUILDINGS = [
    'Central Reservoir',
    'Treatment Plant 1',
    'Treatment Plant 2',
    'Water Process 1',
    'Water Process 2',
    'Power Station',
    'Development Complex',
    'Ammunition Factory',
    'Helipad',
]
ROAMER_GROUP = 'Roamer Group'
GROUPS = BUILDINGS + [ROAMER_GROUP]

# Priority requested by OAO: Center, Treatment, Processing, then the rest.
GROUP_PRIORITY = {
    'Central Reservoir': 1,
    'Treatment Plant 1': 2,
    'Treatment Plant 2': 2,
    'Water Process 1': 3,
    'Water Process 2': 3,
    'Power Station': 4,
    'Development Complex': 4,
    'Ammunition Factory': 4,
    'Helipad': 4,
    ROAMER_GROUP: 5,
}

ASSIGNED_ROLES = [
    'Group Leader',
    'Reinforcement',
    'Building Babysitter',
    'Water Tank',
    'Roamer',
]

# Members choose a preference. Group Leader is leadership-assigned only.
PREFERRED_ROLES = [
    'Reinforcement',
    'Building Babysitter',
    'Water Tank',
    'Roamer',
]

MEMBERS = [
('Queen Ashley',296.49,30),('Winry',292.95,30),('Agent 86',237.46,30),('Wahid1',235.23,30),('cMiller4',208.88,30),('Xander',157.09,27),('NotWinry',154.97,28),('Spotato',146.85,30),('NightVixen',142.10,27),('tomcat',131.26,26),('Maybe winry',121.66,27),('Tyson',120.61,26),('Betz',120.50,26),('SassyNana',107.88,25),('Meow',107.54,26),('TacticalSnuggy',105.82,26),('IronHorse',104.31,26),('Verlore Siel',97.92,24),('KreDeN',96.92,26),('Bucket',94.40,24),('❉AgentDruDarlin❉',93.01,25),('Otto85',92.66,25),('Quicksilver6660',90.42,27),('ping',90.05,25),('TheCandyMan',88.42,25),('Scarnow',87.84,26),('RicSwimmons',87.46,23),('HarleyQ',87.10,24),('Jamz',86.13,26),('Agent BlackOps',85.52,25),('Titan',85.19,25),('MrElectric03',85.18,24),('ventel',84.52,25),('PLtotheB',83.51,23),('GANGRILLA',82.95,23),('Agent Boomhauer',81.51,22),('BearClawZ',80.75,25),('ChknRick',80.65,25),('TheSpartan_300',80.64,23),('Lizard',79.90,25),('Agent Gérard',79.86,24),('Harleybell',77.46,23),('Q. R',76.60,24),('BiGxChuck',75.89,22),('Advent',75.68,23),('Dassem',75.37,24),('Pluxe',75.00,26),('SgtAtArmZz',74.01,25),('Datura',73.38,23),('Jupiter',72.75,23),('WickedPyro611',72.01,25),('Jin',71.96,26),('BMET-FSE',71.42,24),('Savoy',71.32,24),('GabrielValeriote',70.01,25),('Dragon Fly',69.55,24),('b3ndm3ov3r',69.35,22),('Esper',69.28,25),('MaC',68.84,23),('Impholder',68.70,23),('Agent Hellcat',67.35,22),('~Charlie~',66.79,22),('Chiodaved',66.35,24),('Caesar',65.02,25),('Chad ThunderCock',63.82,23),('DaddyMack',63.82,22),('Mini Hell',62.61,10),('Robin',62.59,24),('Darling',62.12,24),('l_hulk_smash',59.21,24),('Nine1sicks',58.37,25),('Kickflip',58.01,23),('Recca',57.52,21),('Sphinctersaywhat',57.26,23),('Flakey',57.06,22),('JayCat',57.02,22),('[OaO]Jarod.sun',51.30,22),('Belirosheton',46.71,22),('@JIMMY@',46.50,22),('Chief Ni_Ro',44.87,22),('C.R.E.A.M',40.60,23),('Msevel',38.71,22),('TioMilho',34.42,20),('TON MG38',33.30,23),('Scuttle-Bucket',17.16,19),('Small Fries',16.84,20),('TheGreenMeanHulk',12.28,17),('Baby Cheeka',9.12,17),('WickedSpark611',4.54,17),('TheFatAlcoholic',3.75,17)
]


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def ensure_col(con, table, col, ddl):
    cols = {r[1] for r in con.execute(f'PRAGMA table_info({table})').fetchall()}
    if col not in cols:
        con.execute(ddl)


def init_db():
    with db() as con:
        con.executescript('''
        CREATE TABLE IF NOT EXISTS alliance_members(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          display_name TEXT NOT NULL COLLATE NOCASE UNIQUE,
          power_m REAL NOT NULL DEFAULT 0,
          plant_level INTEGER NOT NULL DEFAULT 0,
          discord_user_id INTEGER,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS players(
          user_id INTEGER PRIMARY KEY,
          display_name TEXT NOT NULL,
          roster_status TEXT NOT NULL DEFAULT 'active',
          preferred_role TEXT,
          assigned_role TEXT,
          primary_building TEXT,
          power_m REAL NOT NULL DEFAULT 0,
          plant_level INTEGER NOT NULL DEFAULT 0,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS raid_state(
          id INTEGER PRIMARY KEY CHECK(id=1),
          panel_channel_id INTEGER,
          panel_message_id INTEGER
        );
        CREATE TABLE IF NOT EXISTS group_locks(
          group_name TEXT PRIMARY KEY,
          locked INTEGER NOT NULL DEFAULT 0
        );
        INSERT OR IGNORE INTO raid_state(id) VALUES(1);
        ''')
        for col, ddl in {
            'power_m': 'ALTER TABLE players ADD COLUMN power_m REAL NOT NULL DEFAULT 0',
            'plant_level': 'ALTER TABLE players ADD COLUMN plant_level INTEGER NOT NULL DEFAULT 0',
            'preferred_role': 'ALTER TABLE players ADD COLUMN preferred_role TEXT',
            'assigned_role': 'ALTER TABLE players ADD COLUMN assigned_role TEXT',
            'primary_building': 'ALTER TABLE players ADD COLUMN primary_building TEXT',
            'roster_status': "ALTER TABLE players ADD COLUMN roster_status TEXT NOT NULL DEFAULT 'active'",
        }.items():
            ensure_col(con, 'players', col, ddl)
        for col, ddl in {
            'panel_channel_id': 'ALTER TABLE raid_state ADD COLUMN panel_channel_id INTEGER',
            'panel_message_id': 'ALTER TABLE raid_state ADD COLUMN panel_message_id INTEGER',
        }.items():
            ensure_col(con, 'raid_state', col, ddl)
        for n, p, pp in MEMBERS:
            con.execute('INSERT OR IGNORE INTO alliance_members(display_name,power_m,plant_level) VALUES(?,?,?)', (n, p, pp))
        for group in GROUPS:
            con.execute('INSERT OR IGNORE INTO group_locks(group_name,locked) VALUES(?,0)', (group,))


def leadership(member: discord.Member):
    if not isinstance(member, discord.Member):
        return False
    return (
        member.guild_permissions.administrator
        or member.guild_permissions.manage_guild
        or any(r.id in LEADERSHIP_ROLE_IDS for r in member.roles)
    )


def raid_rows(status=None):
    with db() as con:
        if status:
            return con.execute('SELECT * FROM players WHERE roster_status=? ORDER BY power_m DESC, plant_level DESC, display_name COLLATE NOCASE', (status,)).fetchall()
        return con.execute('SELECT * FROM players ORDER BY power_m DESC, plant_level DESC, display_name COLLATE NOCASE').fetchall()


def status_count(status):
    with db() as con:
        return con.execute('SELECT COUNT(*) FROM players WHERE roster_status=?', (status,)).fetchone()[0]


def group_count(group_name):
    with db() as con:
        return con.execute("SELECT COUNT(*) FROM players WHERE roster_status='active' AND primary_building=?", (group_name,)).fetchone()[0]

def group_locked(group_name):
    with db() as con:
        row = con.execute('SELECT locked FROM group_locks WHERE group_name=?', (group_name,)).fetchone()
        return bool(row['locked']) if row else False


def set_group_lock(group_name, locked):
    with db() as con:
        con.execute('INSERT INTO group_locks(group_name,locked) VALUES(?,?) ON CONFLICT(group_name) DO UPDATE SET locked=excluded.locked', (group_name, 1 if locked else 0))


def player_by_discord(user_id):
    with db() as con:
        return con.execute('SELECT * FROM players WHERE user_id=?', (user_id,)).fetchone()


def player_by_name(name):
    with db() as con:
        return con.execute('SELECT * FROM players WHERE display_name=? COLLATE NOCASE', (name,)).fetchone()


def next_manual_user_id():
    # Manual/offline players use negative IDs so they never collide with Discord user IDs.
    with db() as con:
        row = con.execute('SELECT MIN(user_id) FROM players WHERE user_id < 0').fetchone()
        current = row[0] if row and row[0] is not None else 0
        return current - 1 if current < 0 else -1


def manual_add_player(name, power, pp, status='active'):
    name = name.strip()
    if not name:
        return False, 'Player name is required.'
    if player_by_name(name):
        return False, f'**{name}** is already on the raid roster.'
    if power < 0 or power > 300:
        return False, 'Power must be between 0M and 300M.'
    if pp < 10 or pp > 30:
        return False, 'PP level must be between PP10 and PP30.'
    status = status.strip().lower().replace("'", '').replace('’', '')
    aliases = {'active':'active','yes':'active','in':'active','reservist':'reservist','reserve':'reservist','maybe':'maybe','cant':'cant','cant go':'cant','no':'cant'}
    status = aliases.get(status)
    if not status:
        return False, "Status must be Active, Reservist, Maybe, or Can't Go."
    if status == 'active' and status_count('active') >= MAX_ACTIVE:
        return False, 'Active roster is full (30/30). Add them as Reservist or Maybe.'
    if status == 'reservist' and status_count('reservist') >= MAX_RESERVISTS:
        return False, 'Reservists are full (10/10).'
    uid = next_manual_user_id()
    with db() as con:
        con.execute('INSERT INTO alliance_members(display_name,power_m,plant_level) VALUES(?,?,?) ON CONFLICT(display_name) DO UPDATE SET power_m=excluded.power_m,plant_level=excluded.plant_level,updated_at=CURRENT_TIMESTAMP', (name, power, pp))
        con.execute('INSERT INTO players(user_id,display_name,roster_status,power_m,plant_level) VALUES(?,?,?,?,?)', (uid, name, status, power, pp))
    label = "Can't Go" if status == 'cant' else status.title()
    return True, f'Added **{name}** • {int(power)}M • PP{pp} • {label}'


def active_unassigned():
    with db() as con:
        return con.execute("SELECT * FROM players WHERE roster_status='active' AND (primary_building IS NULL OR primary_building='') ORDER BY power_m DESC, plant_level DESC").fetchall()


def upsert_member_profile(user_id, name, power, pp):
    with db() as con:
        linked = con.execute('SELECT * FROM alliance_members WHERE discord_user_id=?', (user_id,)).fetchone()
        named = con.execute('SELECT * FROM alliance_members WHERE display_name=? COLLATE NOCASE', (name,)).fetchone()
        if linked:
            try:
                con.execute('UPDATE alliance_members SET display_name=?,power_m=?,plant_level=?,updated_at=CURRENT_TIMESTAMP WHERE id=?', (name, power, pp, linked['id']))
            except sqlite3.IntegrityError:
                con.execute('UPDATE alliance_members SET power_m=?,plant_level=?,discord_user_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?', (power, pp, user_id, named['id']))
        elif named:
            con.execute('UPDATE alliance_members SET discord_user_id=?,power_m=?,plant_level=?,updated_at=CURRENT_TIMESTAMP WHERE id=?', (user_id, power, pp, named['id']))
        else:
            con.execute('INSERT INTO alliance_members(display_name,power_m,plant_level,discord_user_id) VALUES(?,?,?,?)', (name, power, pp, user_id))


def save_signup(user_id, name, status, power=0, pp=0, preferred_role=None):
    existing = player_by_discord(user_id)
    if status == 'active' and not existing and status_count('active') >= MAX_ACTIVE:
        status = 'reservist'
    if status == 'reservist' and not existing and status_count('reservist') >= MAX_RESERVISTS:
        return False, 'Reservists are full.'
    with db() as con:
        if existing:
            # Changing to maybe/cant clears current group assignment.
            clear_assignment = status not in ('active', 'reservist')
            con.execute('''UPDATE players SET display_name=?,roster_status=?,power_m=?,plant_level=?,preferred_role=?,
                           assigned_role=CASE WHEN ? THEN NULL ELSE assigned_role END,
                           primary_building=CASE WHEN ? THEN NULL ELSE primary_building END,updated_at=CURRENT_TIMESTAMP
                           WHERE user_id=?''',
                        (name, status, power, pp, preferred_role, 1 if clear_assignment else 0, 1 if clear_assignment else 0, user_id))
        else:
            con.execute('INSERT INTO players(user_id,display_name,roster_status,preferred_role,power_m,plant_level) VALUES(?,?,?,?,?,?)',
                        (user_id, name, status, preferred_role, power, pp))
    return True, status


def set_group(user_id, group_name):
    r = player_by_discord(user_id)
    if not r or r['roster_status'] != 'active':
        return False, 'You must be on the Active roster to join a group.'
    if group_name not in GROUPS:
        return False, 'Invalid group.'
    if group_locked(group_name):
        return False, f'**{group_name}** is locked by leadership.'
    if r['primary_building'] == group_name:
        return True, f'You are already in **{group_name}**.'
    if group_count(group_name) >= GROUP_SIZE:
        return False, f'**{group_name}** is full (3/3).'
    with db() as con:
        con.execute('UPDATE players SET primary_building=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (group_name, user_id))
    return True, f'Joined **{group_name}**.'


def set_assignment(user_id, group_name, role=None, leadership_override=False):
    if group_name not in GROUPS:
        return False, 'Invalid group.'
    r = player_by_discord(user_id)
    if not r:
        return False, 'Player not found.'
    if r['roster_status'] != 'active':
        return False, 'Player must be Active first.'
    if r['primary_building'] != group_name and group_count(group_name) >= GROUP_SIZE and not leadership_override:
        return False, f'{group_name} is full.'
    # Leadership can move within caps, but never allow >3.
    if r['primary_building'] != group_name and group_count(group_name) >= GROUP_SIZE:
        return False, f'{group_name} is already 3/3.'
    if role and role not in ASSIGNED_ROLES:
        return False, 'Invalid role.'
    with db() as con:
        # One leader per group. Promoting a new leader automatically demotes the old one.
        if role == 'Group Leader':
            con.execute("UPDATE players SET assigned_role='Reinforcement',updated_at=CURRENT_TIMESTAMP WHERE roster_status='active' AND primary_building=? AND assigned_role='Group Leader' AND user_id<>?", (group_name, user_id))
        if role:
            con.execute('UPDATE players SET primary_building=?,assigned_role=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (group_name, role, user_id))
        else:
            con.execute('UPDATE players SET primary_building=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (group_name, user_id))
    return True, 'Assignment saved.'


def change_assigned_role(user_id, role):
    if role not in ASSIGNED_ROLES:
        return False, 'Invalid role.'
    r = player_by_discord(user_id)
    if not r or r['roster_status'] != 'active':
        return False, 'Player must be Active.'
    if not r['primary_building']:
        return False, 'Assign the player to a building/group first.'
    with db() as con:
        if role == 'Group Leader':
            con.execute("UPDATE players SET assigned_role='Reinforcement',updated_at=CURRENT_TIMESTAMP WHERE roster_status='active' AND primary_building=? AND assigned_role='Group Leader' AND user_id<>?", (r['primary_building'], user_id))
        con.execute('UPDATE players SET assigned_role=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (role, user_id))
    return True, f"{r['display_name']} → {role}"


def clear_assignment(user_id):
    r = player_by_discord(user_id)
    if not r:
        return False, 'Player not found.'
    with db() as con:
        con.execute('UPDATE players SET primary_building=NULL,assigned_role=NULL,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (user_id,))
    return True, f"Cleared assignment for {r['display_name']}."


def update_player_stats(user_id, name, power, pp):
    name = name.strip()
    if not name:
        return False, 'Player name is required.'
    if power < 0 or power > 300:
        return False, 'Power must be between 0M and 300M.'
    if pp < 10 or pp > 30:
        return False, 'PP must be between PP10 and PP30.'
    existing = player_by_name(name)
    if existing and existing['user_id'] != user_id:
        return False, 'Another raid player already uses that name.'
    with db() as con:
        con.execute('UPDATE players SET display_name=?,power_m=?,plant_level=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (name, power, pp, user_id))
        con.execute('INSERT INTO alliance_members(display_name,power_m,plant_level) VALUES(?,?,?) ON CONFLICT(display_name) DO UPDATE SET power_m=excluded.power_m,plant_level=excluded.plant_level,updated_at=CURRENT_TIMESTAMP', (name, power, pp))
    return True, f'Updated {name} • {int(power)}M • PP{pp}'


def group_leader(group_name):
    with db() as con:
        return con.execute("SELECT display_name FROM players WHERE roster_status='active' AND primary_building=? AND assigned_role='Group Leader' LIMIT 1", (group_name,)).fetchone()


def compact_signup_lines(rows, limit=12):
    lines = []
    for r in rows[:limit]:
        group = r['primary_building'] or 'Unassigned'
        role = r['assigned_role'] or (f"Pref: {r['preferred_role']}" if r['preferred_role'] else 'No role')
        lines.append(f"• **{r['display_name']}** — {int(r['power_m'])}M • PP{r['plant_level']} • {role} • {group}")
    if len(rows) > limit:
        lines.append(f"…and {len(rows)-limit} more")
    return '\n'.join(lines) or 'None'


def home_embed():
    active = raid_rows('active')
    reservists = raid_rows('reservist')
    maybe = raid_rows('maybe')
    cant = raid_rows('cant')
    assigned = sum(1 for r in active if r['primary_building'])
    e = discord.Embed(
        title='OAO RESERVOIR RAID',
        description='**Sign Up → Join Group → Check My Orders**',
    )
    e.add_field(name='STATUS', value=(
        f'**Active:** {len(active)}/30\n'
        f'**Reservists:** {len(reservists)}/10\n'
        f'**Maybe:** {len(maybe)}\n'
        f"**Can't Go:** {len(cant)}\n"
        f'**Assigned:** {assigned}/{len(active)}'
    ), inline=True)
    e.add_field(name='GROUPS', value=(
        f'9 building groups × 3 = 27\n'
        f'Roamer Group × 3 = 3\n'
        f'**Total: 30**'
    ), inline=True)
    needs = [f"{g}: {group_count(g)}/3" for g in GROUPS if group_count(g) < GROUP_SIZE]
    e.add_field(name='NEEDS PLAYERS', value='\n'.join(needs[:10]) or 'All groups full.', inline=False)
    e.add_field(name='SIGNED UP', value=compact_signup_lines(active, 8)[:1024], inline=False)
    if maybe:
        e.add_field(name=f'MAYBE ({len(maybe)})', value=' • '.join(r['display_name'] for r in maybe)[:1024], inline=False)
    e.set_footer(text=f'v{BOT_VERSION} • This panel auto-updates after signups and group changes.')
    return e


def roster_embed():
    e = discord.Embed(title='RAID ROSTER')
    for status, label in [('active', 'ACTIVE'), ('reservist', 'RESERVISTS'), ('maybe', 'MAYBE'), ('cant', "CAN'T GO")]:
        rows = raid_rows(status)
        text = '\n'.join(f"• {r['display_name']} — {int(r['power_m'])}M • PP{r['plant_level']}" for r in rows) or 'None'
        # Split only if necessary.
        if len(text) <= 1024:
            e.add_field(name=f'{label} ({len(rows)})', value=text, inline=False)
        else:
            chunks = []
            current = ''
            for line in text.splitlines():
                if len(current) + len(line) + 1 > 1000:
                    chunks.append(current)
                    current = line
                else:
                    current += ('\n' if current else '') + line
            if current:
                chunks.append(current)
            for idx, chunk in enumerate(chunks):
                e.add_field(name=f'{label} ({len(rows)})' if idx == 0 else f'{label} continued', value=chunk, inline=False)
    return e


def assignments_embed():
    active = raid_rows('active')
    assigned = sum(1 for r in active if r['primary_building'])
    e = discord.Embed(title='GROUP LEADERS + BUILDING ASSIGNMENTS', description=f'**Active:** {len(active)}/30 • **Assigned:** {assigned}/{len(active)}')
    for group in GROUPS:
        members = [r for r in active if r['primary_building'] == group]
        leader = next((r for r in members if r['assigned_role'] == 'Group Leader'), None)
        lines = [f"**Leader:** {leader['display_name'] if leader else 'OPEN'}"]
        for r in members:
            if leader and r['user_id'] == leader['user_id']:
                continue
            lines.append(f"• {r['display_name']} — {r['assigned_role'] or 'No role'}")
        while len(members) < GROUP_SIZE:
            lines.append('• OPEN')
            members.append(None)
        lock_label = ' • LOCKED' if group_locked(group) else ''
        e.add_field(name=f"{group} ({group_count(group)}/3){lock_label}", value='\n'.join(lines)[:1024], inline=True)
    unassigned = [r for r in active if not r['primary_building']]
    if unassigned:
        e.add_field(name=f'UNASSIGNED ({len(unassigned)})', value='\n'.join(f"• {r['display_name']} — {r['assigned_role'] or 'No role'}" for r in unassigned)[:1024], inline=False)
    return e


async def save_panel_message(message: discord.Message):
    with db() as con:
        con.execute('UPDATE raid_state SET panel_channel_id=?,panel_message_id=? WHERE id=1', (message.channel.id, message.id))


async def refresh_panel():
    with db() as con:
        s = con.execute('SELECT panel_channel_id,panel_message_id FROM raid_state WHERE id=1').fetchone()
    if not s or not s['panel_channel_id'] or not s['panel_message_id']:
        return
    try:
        channel = bot.get_channel(s['panel_channel_id']) or await bot.fetch_channel(s['panel_channel_id'])
        message = await channel.fetch_message(s['panel_message_id'])
        await message.edit(embed=home_embed(), view=Home())
    except Exception as exc:
        print('Panel refresh skipped:', exc)


class Home(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label='SIGN UP', style=discord.ButtonStyle.success, custom_id='rr_v8_signup', row=0)
    async def signup(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(PlayerNameModal())

    @discord.ui.button(label='JOIN GROUP', style=discord.ButtonStyle.primary, custom_id='rr_v8_join', row=0)
    async def join(self, interaction: discord.Interaction, button: discord.ui.Button):
        r = player_by_discord(interaction.user.id)
        if not r or r['roster_status'] != 'active':
            await interaction.response.send_message('Sign up **YES** first, then join a group.', ephemeral=True)
            return
        await interaction.response.send_message('Choose a group. Every group is **3 players max**.', view=JoinGroupView(), ephemeral=True)

    @discord.ui.button(label='MY ORDERS', style=discord.ButtonStyle.primary, custom_id='rr_v8_orders', row=1)
    async def orders(self, interaction: discord.Interaction, button: discord.ui.Button):
        r = player_by_discord(interaction.user.id)
        if not r:
            await interaction.response.send_message('You have not signed up yet.', ephemeral=True)
            return
        leader = group_leader(r['primary_building']) if r['primary_building'] else None
        e = discord.Embed(title='YOUR ORDERS')
        e.description = f"**{r['display_name']}**\nStatus: **{r['roster_status'].replace('_',' ').title()}**"
        e.add_field(name='Assignment', value=(
            f"**Group:** {r['primary_building'] or 'Unassigned'}\n"
            f"**Role:** {r['assigned_role'] or 'Unassigned'}\n"
            f"**Leader:** {leader['display_name'] if leader else 'Unassigned'}"
        ), inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @discord.ui.button(label='ROSTER', style=discord.ButtonStyle.secondary, custom_id='rr_v8_roster', row=1)
    async def roster(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=roster_embed(), ephemeral=True)

    @discord.ui.button(label='ASSIGNMENTS', style=discord.ButtonStyle.secondary, custom_id='rr_v8_assignments', row=2)
    async def assignments(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=assignments_embed(), ephemeral=True)

    @discord.ui.button(label='MAP', style=discord.ButtonStyle.secondary, custom_id='rr_v8_map', row=2)
    async def map_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if MAP_PATH.exists():
            await interaction.response.send_message(file=discord.File(MAP_PATH), ephemeral=True)
        else:
            await interaction.response.send_message('Map file missing.', ephemeral=True)

    @discord.ui.button(label='LEADERSHIP', style=discord.ButtonStyle.danger, custom_id='rr_v8_admin', row=3)
    async def admin(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not leadership(interaction.user):
            await interaction.response.send_message('Leadership only.', ephemeral=True)
            return
        await interaction.response.send_message(embed=discord.Embed(title='RESERVOIR CONTROL', description='Simple setup and live controls.'), view=LeadershipView(), ephemeral=True)


class PlayerNameModal(discord.ui.Modal, title='Reservoir Sign Up'):
    player_name = discord.ui.TextInput(label='Tile Survive player name', placeholder='Your in-game name', max_length=40)

    async def on_submit(self, interaction: discord.Interaction):
        name = str(self.player_name).strip()
        if not name:
            await interaction.response.send_message('Enter your Tile Survive player name.', ephemeral=True)
            return
        await interaction.response.send_message(f'Player: **{name}**\nCan you make Reservoir?', view=AttendanceView(name), ephemeral=True)


class AttendanceView(discord.ui.View):
    def __init__(self, name):
        super().__init__(timeout=180)
        self.name = name

    async def choose(self, interaction, status):
        if status == 'cant':
            existing = player_by_discord(interaction.user.id)
            power = existing['power_m'] if existing else 0
            pp = existing['plant_level'] if existing else 0
            role = existing['preferred_role'] if existing else None
            upsert_member_profile(interaction.user.id, self.name, power, pp)
            save_signup(interaction.user.id, self.name, 'cant', power, pp, role)
            await interaction.response.edit_message(content=f"Saved: **{self.name} — CAN'T GO**", view=None)
            await refresh_panel()
            return
        await interaction.response.edit_message(content=f"Player: **{self.name}** • {'YES' if status=='active' else 'MAYBE'}\nChoose PP level:", view=PPView(self.name, status))

    @discord.ui.button(label='YES', style=discord.ButtonStyle.success)
    async def yes(self, interaction, button):
        await self.choose(interaction, 'active')

    @discord.ui.button(label='MAYBE', style=discord.ButtonStyle.secondary)
    async def maybe(self, interaction, button):
        await self.choose(interaction, 'maybe')

    @discord.ui.button(label="CAN'T GO", style=discord.ButtonStyle.danger)
    async def cant(self, interaction, button):
        await self.choose(interaction, 'cant')


class PPView(discord.ui.View):
    def __init__(self, name, status):
        super().__init__(timeout=180)
        self.add_item(PPSelect(name, status))


class PPSelect(discord.ui.Select):
    def __init__(self, name, status):
        self.name = name
        self.status = status
        options = [discord.SelectOption(label=f'PP{x}', value=str(x)) for x in range(10, 31)]
        super().__init__(placeholder='Choose PP level', options=options)

    async def callback(self, interaction):
        pp = int(self.values[0])
        await interaction.response.edit_message(content=f'**{self.name} • PP{pp}**\nChoose power range:', view=PowerRangeView(self.name, self.status, pp))


class PowerRangeView(discord.ui.View):
    def __init__(self, name, status, pp):
        super().__init__(timeout=180)
        self.add_item(PowerRangeSelect(name, status, pp))


class PowerRangeSelect(discord.ui.Select):
    def __init__(self, name, status, pp):
        self.name = name
        self.status = status
        self.pp = pp
        options = [
            discord.SelectOption(label='10M–100M', value='10'),
            discord.SelectOption(label='110M–200M', value='110'),
            discord.SelectOption(label='210M–300M', value='210'),
        ]
        super().__init__(placeholder='Choose power range', options=options)

    async def callback(self, interaction):
        start = int(self.values[0])
        await interaction.response.edit_message(content=f'**{self.name} • PP{self.pp}**\nChoose power:', view=PowerView(self.name, self.status, self.pp, start))


class PowerView(discord.ui.View):
    def __init__(self, name, status, pp, start):
        super().__init__(timeout=180)
        self.add_item(PowerSelect(name, status, pp, start))


class PowerSelect(discord.ui.Select):
    def __init__(self, name, status, pp, start):
        self.name = name
        self.status = status
        self.pp = pp
        values = list(range(start, min(start + 90, 300) + 1, 10))
        options = [discord.SelectOption(label=f'{x}M', value=str(x)) for x in values]
        super().__init__(placeholder='Power', options=options)

    async def callback(self, interaction):
        power = int(self.values[0])
        await interaction.response.edit_message(content=f'**{self.name} • {power}M • PP{self.pp}**\nChoose your preferred role:', view=RoleView(self.name, self.status, self.pp, power))


class RoleView(discord.ui.View):
    def __init__(self, name, status, pp, power):
        super().__init__(timeout=180)
        self.add_item(RoleSelect(name, status, pp, power))


class RoleSelect(discord.ui.Select):
    def __init__(self, name, status, pp, power):
        self.name = name
        self.status = status
        self.pp = pp
        self.power = power
        options = [discord.SelectOption(label=r) for r in PREFERRED_ROLES]
        super().__init__(placeholder='Preferred role', options=options)

    async def callback(self, interaction):
        role = self.values[0]
        upsert_member_profile(interaction.user.id, self.name, self.power, self.pp)
        ok, final_status = save_signup(interaction.user.id, self.name, self.status, self.power, self.pp, role)
        if not ok:
            await interaction.response.edit_message(content=final_status, view=None)
            return
        pretty = {'active': 'YES — ACTIVE', 'reservist': 'RESERVIST', 'maybe': 'MAYBE'}[final_status]
        text = f"**SIGNUP SAVED**\n{self.name} • {self.power}M • PP{self.pp}\n{pretty} • Preferred: {role}"
        if final_status == 'active':
            await interaction.response.edit_message(content=text + '\n\nNext: **JOIN A GROUP**', view=JoinGroupView())
        else:
            await interaction.response.edit_message(content=text, view=None)
        await refresh_panel()


class JoinGroupView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        self.add_item(JoinGroupSelect())


class JoinGroupSelect(discord.ui.Select):
    def __init__(self):
        options = []
        for group in GROUPS:
            c = group_count(group)
            options.append(discord.SelectOption(
                label=group,
                value=group,
                description=f'{c}/3' + (' • LOCKED' if group_locked(group) else (' • FULL' if c >= 3 else ''))
            ))
        super().__init__(placeholder='Choose group', options=options)

    async def callback(self, interaction):
        ok, msg = set_group(interaction.user.id, self.values[0])
        await interaction.response.edit_message(content=msg, view=None)
        if ok:
            await refresh_panel()


class LeadershipView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)

    async def check(self, interaction):
        if not leadership(interaction.user):
            await interaction.response.send_message('Leadership only.', ephemeral=True)
            return False
        return True

    @discord.ui.button(label='ASSIGN PLAYER', style=discord.ButtonStyle.success, row=0)
    async def assign_player(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_message('Pick an Active player:', view=LeadershipPlayerPick(), ephemeral=True)

    @discord.ui.button(label='ADD PLAYER', style=discord.ButtonStyle.success, row=0)
    async def add_player(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_modal(ManualAddPlayerModal())

    @discord.ui.button(label='FIND PLAYER', style=discord.ButtonStyle.secondary, row=1)
    async def find_player(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_modal(FindPlayerModal())

    @discord.ui.button(label='AUTO ASSIGN', style=discord.ButtonStyle.primary, row=0)
    async def auto_assign(self, interaction, button):
        if not await self.check(interaction): return
        active = raid_rows('active')[:MAX_ACTIVE]
        if not active:
            await interaction.response.send_message('No Active players yet.', ephemeral=True)
            return
        # Simple starting point: strongest Power/PP first, then preferred roles.
        active = sorted(active, key=lambda r: (float(r['power_m']), int(r['plant_level'])), reverse=True)
        with db() as con:
            con.execute("UPDATE players SET primary_building=NULL,assigned_role=NULL WHERE roster_status='active'")
            idx = 0
            ordered_groups = sorted(GROUPS, key=lambda g: (GROUP_PRIORITY[g], GROUPS.index(g)))
            for group in ordered_groups:
                chunk = active[idx:idx + GROUP_SIZE]
                idx += len(chunk)
                for pos, r in enumerate(chunk):
                    if pos == 0:
                        role = 'Group Leader'
                    elif group == ROAMER_GROUP:
                        role = 'Roamer'
                    else:
                        pref = r['preferred_role'] if r['preferred_role'] in PREFERRED_ROLES else None
                        role = pref or 'Reinforcement'
                    con.execute('UPDATE players SET primary_building=?,assigned_role=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (group, role, r['user_id']))
                if idx >= len(active):
                    break
        await interaction.response.send_message('Auto Assign finished. Review **ASSIGNMENTS** and adjust anything you want.', ephemeral=True)
        await refresh_panel()

    @discord.ui.button(label='ASSIGNMENTS', style=discord.ButtonStyle.secondary, row=2)
    async def assignments(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_message(embed=assignments_embed(), ephemeral=True)

    @discord.ui.button(label='ROSTER', style=discord.ButtonStyle.secondary, row=2)
    async def roster(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_message(embed=roster_embed(), view=RosterManageView(), ephemeral=True)

    @discord.ui.button(label='GROUPS', style=discord.ButtonStyle.secondary, row=3)
    async def groups(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_message('Choose a group to lock or unlock:', view=GroupLockPickView(), ephemeral=True)

    @discord.ui.button(label='SWAP PLAYERS', style=discord.ButtonStyle.primary, row=3)
    async def swap_players(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_modal(SwapPlayersModal())

    @discord.ui.button(label='LIVE CALL', style=discord.ButtonStyle.danger, row=4)
    async def live_call(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_message('Choose the call:', view=LiveCallView(), ephemeral=True)

    @discord.ui.button(label='RESET RAID', style=discord.ButtonStyle.danger, row=4)
    async def reset(self, interaction, button):
        if not await self.check(interaction): return
        await interaction.response.send_message('Clear this raid signup, roster and assignments? Player database stays saved.', view=ResetView(), ephemeral=True)


class GroupLockPickView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        self.add_item(GroupLockSelect())


class GroupLockSelect(discord.ui.Select):
    def __init__(self):
        options = [discord.SelectOption(label=g, value=g, description='LOCKED' if group_locked(g) else 'OPEN') for g in GROUPS]
        super().__init__(placeholder='Choose group', options=options)

    async def callback(self, interaction):
        group = self.values[0]
        await interaction.response.edit_message(content=f'**{group}** is currently **{"LOCKED" if group_locked(group) else "OPEN"}**.', view=GroupLockActionView(group))


class GroupLockActionView(discord.ui.View):
    def __init__(self, group):
        super().__init__(timeout=180)
        self.group = group

    @discord.ui.button(label='LOCK', style=discord.ButtonStyle.danger)
    async def lock(self, interaction, button):
        set_group_lock(self.group, True)
        await interaction.response.edit_message(content=f'**{self.group} locked.** Players cannot self-join it.', view=None)
        await refresh_panel()

    @discord.ui.button(label='UNLOCK', style=discord.ButtonStyle.success)
    async def unlock(self, interaction, button):
        set_group_lock(self.group, False)
        await interaction.response.edit_message(content=f'**{self.group} unlocked.** Players can self-join if space is available.', view=None)
        await refresh_panel()


class FindPlayerModal(discord.ui.Modal, title='Find Player'):
    player_name = discord.ui.TextInput(label='Tile Survive player name', placeholder='Exact or partial name', max_length=40)

    async def on_submit(self, interaction):
        if not leadership(interaction.user):
            await interaction.response.send_message('Leadership only.', ephemeral=True)
            return
        term = str(self.player_name).strip()
        with db() as con:
            rows = con.execute("SELECT * FROM players WHERE display_name LIKE ? COLLATE NOCASE ORDER BY roster_status='active' DESC,power_m DESC LIMIT 10", (f'%{term}%',)).fetchall()
        if not rows:
            await interaction.response.send_message('No raid player found with that name.', ephemeral=True, delete_after=30)
            return
        if len(rows) == 1:
            r = rows[0]
            await interaction.response.send_message(
                f"**{r['display_name']}** • {int(r['power_m'])}M • PP{r['plant_level']}\nBuilding: **{r['primary_building'] or 'Unassigned'}** • Role: **{r['assigned_role'] or 'Unassigned'}**",
                view=PlayerManageView(r['user_id']), ephemeral=True)
            return
        await interaction.response.send_message('Choose player:', view=SearchResultsView(rows), ephemeral=True)


class SearchResultsView(discord.ui.View):
    def __init__(self, rows):
        super().__init__(timeout=180)
        self.add_item(SearchResultsSelect(rows))


class SearchResultsSelect(discord.ui.Select):
    def __init__(self, rows):
        opts=[discord.SelectOption(label=r['display_name'][:100], description=f"{r['roster_status'].title()} • {int(r['power_m'])}M • PP{r['plant_level']}", value=str(r['user_id'])) for r in rows[:25]]
        super().__init__(placeholder='Choose player', options=opts)

    async def callback(self, interaction):
        r=player_by_discord(int(self.values[0]))
        await interaction.response.edit_message(
            content=f"**{r['display_name']}** • {int(r['power_m'])}M • PP{r['plant_level']}\nStatus: **{r['roster_status'].title()}**\nBuilding: **{r['primary_building'] or 'Unassigned'}**\nRole: **{r['assigned_role'] or 'Unassigned'}**",
            view=PlayerManageView(r['user_id']))


class SwapPlayersModal(discord.ui.Modal, title='Swap Players'):
    player_a = discord.ui.TextInput(label='Player A', placeholder='Exact Tile Survive name', max_length=40)
    player_b = discord.ui.TextInput(label='Player B', placeholder='Exact Tile Survive name', max_length=40)

    async def on_submit(self, interaction):
        if not leadership(interaction.user):
            await interaction.response.send_message('Leadership only.', ephemeral=True)
            return
        a = player_by_name(str(self.player_a).strip())
        b = player_by_name(str(self.player_b).strip())
        if not a or not b:
            await interaction.response.send_message('Both players must be on the current raid roster. Check the names and try again.', ephemeral=True)
            return
        if a['roster_status'] != 'active' or b['roster_status'] != 'active':
            await interaction.response.send_message('Both players must be Active to swap assignments.', ephemeral=True)
            return
        with db() as con:
            con.execute('UPDATE players SET primary_building=?,assigned_role=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (b['primary_building'], b['assigned_role'], a['user_id']))
            con.execute('UPDATE players SET primary_building=?,assigned_role=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (a['primary_building'], a['assigned_role'], b['user_id']))
        await interaction.response.send_message(f"Swapped **{a['display_name']}** and **{b['display_name']}**.", ephemeral=True)
        await refresh_panel()


class ManualAddPlayerModal(discord.ui.Modal, title='Add Player'):
    player_name = discord.ui.TextInput(label='Tile Survive player name', placeholder='In-game name', max_length=40)
    power = discord.ui.TextInput(label='Power (millions)', placeholder='Example: 150', max_length=6)
    pp = discord.ui.TextInput(label='PP Level', placeholder='10-30', max_length=2)
    status = discord.ui.TextInput(label='Status', placeholder="Active / Reservist / Maybe / Can't Go", default='Active', max_length=20)

    async def on_submit(self, interaction):
        if not leadership(interaction.user):
            await interaction.response.send_message('Leadership only.', ephemeral=True)
            return
        try:
            power = float(str(self.power).strip().replace('M','').replace('m',''))
            pp = int(str(self.pp).strip().upper().replace('PP',''))
        except ValueError:
            await interaction.response.send_message('Use numbers for Power and PP. Example: **150** and **27**.', ephemeral=True)
            return
        ok, msg = manual_add_player(str(self.player_name), power, pp, str(self.status))
        await interaction.response.send_message(msg, ephemeral=True)
        if ok:
            await refresh_panel()


class LeadershipPlayerPick(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        self.add_item(LeadershipPlayerSelect())


class LeadershipPlayerSelect(discord.ui.Select):
    def __init__(self):
        rows = raid_rows('active')[:25]
        options = [discord.SelectOption(label=r['display_name'][:100], description=f"{int(r['power_m'])}M • PP{r['plant_level']}", value=str(r['user_id'])) for r in rows]
        if not options:
            options = [discord.SelectOption(label='No Active players', value='0')]
        super().__init__(placeholder='Choose player', options=options)

    async def callback(self, interaction):
        uid = int(self.values[0])
        if uid == 0:
            await interaction.response.edit_message(content='No Active players.', view=None)
            return
        r = player_by_discord(uid)
        await interaction.response.edit_message(
            content=(f"**{r['display_name']}** • {int(r['power_m'])}M • PP{r['plant_level']}\n"
                     f"Status: **{r['roster_status'].title()}**\n"
                     f"Building: **{r['primary_building'] or 'Unassigned'}**\n"
                     f"Role: **{r['assigned_role'] or 'Unassigned'}**"),
            view=PlayerManageView(uid)
        )


class PlayerManageView(discord.ui.View):
    def __init__(self, uid):
        super().__init__(timeout=300)
        self.uid = uid

    @discord.ui.button(label='CHANGE ROLE', style=discord.ButtonStyle.primary, row=0)
    async def change_role(self, interaction, button):
        r = player_by_discord(self.uid)
        if not r or not r['primary_building']:
            await interaction.response.edit_message(content='Assign this player to a building/group first.', view=self)
            return
        await interaction.response.edit_message(content=f"Change **{r['display_name']}** role:", view=ChangeRoleView(self.uid))

    @discord.ui.button(label='CHANGE BUILDING', style=discord.ButtonStyle.success, row=0)
    async def change_building(self, interaction, button):
        r = player_by_discord(self.uid)
        role = r['assigned_role'] if r and r['assigned_role'] in ASSIGNED_ROLES else 'Reinforcement'
        await interaction.response.edit_message(content=f"Move **{r['display_name']}** to:", view=QuickAssignButtons(self.uid, role))

    @discord.ui.button(label='FULL ASSIGN', style=discord.ButtonStyle.success, row=0)
    async def full_assign(self, interaction, button):
        await interaction.response.edit_message(content='Choose role:', view=LeadershipRolePick(self.uid))

    @discord.ui.button(label='CLEAR ASSIGNMENT', style=discord.ButtonStyle.secondary, row=1)
    async def clear(self, interaction, button):
        ok, msg = clear_assignment(self.uid)
        await interaction.response.edit_message(content=msg, view=None)
        if ok: await refresh_panel()

    @discord.ui.button(label='EDIT PLAYER', style=discord.ButtonStyle.secondary, row=1)
    async def edit(self, interaction, button):
        await interaction.response.send_modal(EditPlayerModal(self.uid))

    @discord.ui.button(label='ROSTER STATUS', style=discord.ButtonStyle.secondary, row=1)
    async def roster_status(self, interaction, button):
        await interaction.response.edit_message(content='Choose roster status:', view=RosterStatusButtons(self.uid))


class ChangeRoleView(discord.ui.View):
    def __init__(self, uid):
        super().__init__(timeout=180)
        self.uid = uid
        self.add_item(ChangeRoleSelect(uid))


class ChangeRoleSelect(discord.ui.Select):
    def __init__(self, uid):
        self.uid = uid
        super().__init__(placeholder='Choose new role', options=[discord.SelectOption(label=r) for r in ASSIGNED_ROLES])

    async def callback(self, interaction):
        ok, msg = change_assigned_role(self.uid, self.values[0])
        await interaction.response.edit_message(content=f'**{msg}**' if ok else msg, view=None)
        if ok: await refresh_panel()


class EditPlayerModal(discord.ui.Modal, title='Edit Player'):
    def __init__(self, uid):
        super().__init__()
        self.uid = uid
        r = player_by_discord(uid)
        self.name_input = discord.ui.TextInput(label='Tile Survive name', default=(r['display_name'] if r else ''), max_length=40)
        self.power_input = discord.ui.TextInput(label='Power (millions)', default=(str(int(r['power_m'])) if r else '0'), max_length=6)
        self.pp_input = discord.ui.TextInput(label='PP Level', default=(str(r['plant_level']) if r else '10'), max_length=2)
        self.add_item(self.name_input)
        self.add_item(self.power_input)
        self.add_item(self.pp_input)

    async def on_submit(self, interaction):
        try:
            power = float(str(self.power_input).strip().replace('M','').replace('m',''))
            pp = int(str(self.pp_input).strip().upper().replace('PP',''))
        except ValueError:
            await interaction.response.send_message('Use numbers for Power and PP.', ephemeral=True, delete_after=30)
            return
        ok, msg = update_player_stats(self.uid, str(self.name_input), power, pp)
        await interaction.response.send_message(msg, ephemeral=True, delete_after=30)
        if ok: await refresh_panel()


class LeadershipRolePick(discord.ui.View):
    def __init__(self, uid):
        super().__init__(timeout=300)
        self.add_item(LeadershipRoleSelect(uid))


class LeadershipRoleSelect(discord.ui.Select):
    def __init__(self, uid):
        self.uid = uid
        super().__init__(placeholder='Choose role', options=[discord.SelectOption(label=r) for r in ASSIGNED_ROLES])

    async def callback(self, interaction):
        role = self.values[0]
        await interaction.response.edit_message(content=f'Role: **{role}**\nTap the group/building:', view=QuickAssignButtons(self.uid, role))


class QuickAssignButtons(discord.ui.View):
    def __init__(self, uid, role):
        super().__init__(timeout=300)
        self.uid = uid
        self.role = role
        labels = [
            ('CENTER', 'Central Reservoir'),
            ('TREAT 1', 'Treatment Plant 1'),
            ('TREAT 2', 'Treatment Plant 2'),
            ('PROCESS 1', 'Water Process 1'),
            ('PROCESS 2', 'Water Process 2'),
            ('POWER', 'Power Station'),
            ('DEVELOP', 'Development Complex'),
            ('AMMO', 'Ammunition Factory'),
            ('HELIPAD', 'Helipad'),
            ('ROAMERS', ROAMER_GROUP),
        ]
        for idx, (label, group) in enumerate(labels):
            button = discord.ui.Button(label=label, style=discord.ButtonStyle.primary, row=idx // 5)
            async def callback(interaction, group=group):
                ok, msg = set_assignment(self.uid, group, self.role, leadership_override=True)
                if ok:
                    r = player_by_discord(self.uid)
                    msg = f"**{r['display_name']} → {group} → {self.role}**"
                await interaction.response.edit_message(content=msg, view=None)
                if ok:
                    await refresh_panel()
            button.callback = callback
            self.add_item(button)


class RosterManageView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        self.add_item(RosterPlayerSelect())


class RosterPlayerSelect(discord.ui.Select):
    def __init__(self):
        rows = raid_rows()[:25]
        options = [discord.SelectOption(label=r['display_name'][:100], description=r['roster_status'].title(), value=str(r['user_id'])) for r in rows]
        if not options:
            options = [discord.SelectOption(label='No signups', value='0')]
        super().__init__(placeholder='Move a player', options=options)

    async def callback(self, interaction):
        uid = int(self.values[0])
        if uid == 0:
            await interaction.response.edit_message(content='No signups yet.', view=None)
            return
        await interaction.response.edit_message(content='Choose roster status:', view=RosterStatusButtons(uid))


class RosterStatusButtons(discord.ui.View):
    def __init__(self, uid):
        super().__init__(timeout=180)
        self.uid = uid

    async def move(self, interaction, status):
        r = player_by_discord(self.uid)
        if not r:
            await interaction.response.edit_message(content='Player not found.', view=None)
            return
        if status == 'active' and r['roster_status'] != 'active' and status_count('active') >= MAX_ACTIVE:
            await interaction.response.edit_message(content='Active roster is full (30/30).', view=None)
            return
        if status == 'reservist' and r['roster_status'] != 'reservist' and status_count('reservist') >= MAX_RESERVISTS:
            await interaction.response.edit_message(content='Reservists are full (10/10).', view=None)
            return
        with db() as con:
            con.execute("UPDATE players SET roster_status=?,primary_building=CASE WHEN ? IN ('maybe','cant','reservist') THEN NULL ELSE primary_building END,assigned_role=CASE WHEN ? IN ('maybe','cant','reservist') THEN NULL ELSE assigned_role END,updated_at=CURRENT_TIMESTAMP WHERE user_id=?", (status, status, status, self.uid))
        await interaction.response.edit_message(content=f"**{r['display_name']} → {status.replace('_',' ').title()}**", view=None)
        await refresh_panel()

    @discord.ui.button(label='ACTIVE', style=discord.ButtonStyle.success)
    async def active(self, interaction, button): await self.move(interaction, 'active')
    @discord.ui.button(label='RESERVIST', style=discord.ButtonStyle.primary)
    async def reservist(self, interaction, button): await self.move(interaction, 'reservist')
    @discord.ui.button(label='MAYBE', style=discord.ButtonStyle.secondary)
    async def maybe(self, interaction, button): await self.move(interaction, 'maybe')
    @discord.ui.button(label="CAN'T GO", style=discord.ButtonStyle.danger)
    async def cant(self, interaction, button): await self.move(interaction, 'cant')


class LiveCallView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)

    async def choose(self, interaction, action):
        await interaction.response.edit_message(content=f'**{action}** — choose group/building:', view=LiveGroupSelectView(action))

    @discord.ui.button(label='PUSH', style=discord.ButtonStyle.danger)
    async def push(self, i, b): await self.choose(i, 'PUSH')
    @discord.ui.button(label='REINFORCE', style=discord.ButtonStyle.success)
    async def reinforce(self, i, b): await self.choose(i, 'REINFORCE')
    @discord.ui.button(label='HOLD', style=discord.ButtonStyle.primary)
    async def hold(self, i, b): await self.choose(i, 'HOLD')
    @discord.ui.button(label='ROTATE', style=discord.ButtonStyle.secondary)
    async def rotate(self, i, b): await self.choose(i, 'ROTATE')
    @discord.ui.button(label='WATER TANK', style=discord.ButtonStyle.secondary)
    async def tank(self, i, b):
        await i.response.send_message('**OAO CALL — WATER TANK**\nWater Tank players move now. Everyone else hold assignments.', allowed_mentions=discord.AllowedMentions.none(), delete_after=45)
    @discord.ui.button(label='ALL CENTER', style=discord.ButtonStyle.danger)
    async def center(self, i, b):
        await i.response.send_message('**OAO CALL — ALL CENTER**\nAll available Reinforcement and Roamer players move to **Central Reservoir**.', allowed_mentions=discord.AllowedMentions.none(), delete_after=60)


class LiveGroupSelectView(discord.ui.View):
    def __init__(self, action):
        super().__init__(timeout=180)
        self.add_item(LiveGroupSelect(action))


class LiveGroupSelect(discord.ui.Select):
    def __init__(self, action):
        self.action = action
        super().__init__(placeholder='Choose group/building', options=[discord.SelectOption(label=g) for g in GROUPS])

    async def callback(self, interaction):
        group = self.values[0]
        await interaction.response.send_message(f'**OAO CALL — {self.action} {group.upper()}**\nAssigned group executes. Everyone else holds.', allowed_mentions=discord.AllowedMentions.none(), delete_after=45)


class ResetView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)

    @discord.ui.button(label='YES, RESET', style=discord.ButtonStyle.danger)
    async def yes(self, interaction, button):
        with db() as con:
            con.execute('DELETE FROM players')
            con.execute('UPDATE group_locks SET locked=0')
        await interaction.response.edit_message(content='Raid reset. OAO player database was kept.', view=None)
        await refresh_panel()

    @discord.ui.button(label='CANCEL', style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction, button):
        await interaction.response.edit_message(content='Cancelled.', view=None)


intents = discord.Intents.default()
bot = commands.Bot(command_prefix='!', intents=intents)


@bot.event
async def on_ready():
    bot.add_view(Home())
    if GUILD_ID:
        guild = discord.Object(id=GUILD_ID)
        try:
            bot.tree.copy_global_to(guild=guild)
            await bot.tree.sync(guild=guild)
        except Exception as exc:
            print('Guild sync failed:', exc)
    else:
        try:
            await bot.tree.sync()
        except Exception as exc:
            print('Global sync failed:', exc)
    print(f'Logged in as {bot.user} | OAO RR {BOT_VERSION}')


@bot.tree.command(name='rr', description='Open the OAO Reservoir Raid panel')
async def rr(interaction: discord.Interaction):
    await interaction.response.send_message(embed=home_embed(), view=Home())
    message = await interaction.original_response()
    await save_panel_message(message)


@bot.tree.command(name='rr_assignments', description='Show group leaders and building assignments')
async def rr_assignments(interaction: discord.Interaction):
    await interaction.response.send_message(embed=assignments_embed(), ephemeral=True)


@bot.tree.command(name='rr_roster', description='Show Reservoir signup roster')
async def rr_roster(interaction: discord.Interaction):
    await interaction.response.send_message(embed=roster_embed(), ephemeral=True)


init_db()
if not TOKEN:
    raise RuntimeError('DISCORD_TOKEN is missing from .env')
bot.run(TOKEN)
