import os
import sqlite3
from dataclasses import dataclass
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = int(os.getenv("GUILD_ID", "0") or 0)
LEADERSHIP_ROLE_IDS = {
    int(x.strip()) for x in os.getenv("LEADERSHIP_ROLE_IDS", "").split(",") if x.strip().isdigit()
}

DB_PATH = "reservoir.db"
MAP_PATH = os.path.join("assets", "reservoir_map.png")
MAX_ACTIVE = 30
MAX_RESERVISTS = 10

BUILDINGS = [
    "Water Process 1",
    "Power Station",
    "Development Complex",
    "Water Process 2",
    "Treatment Plant 1",
    "Central Reservoir",
    "Treatment Plant 2",
    "Water Process 3",
    "Ammunition Factory",
    "Helipad",
    "Water Process 4",
]

QUADRANTS = ["NW", "NE", "SW", "SE", "CENTER"]
ROLES = ["Rally Anchor", "Fast Capper", "Support", "Defense", "Flex", "Water Runner", "No Preference"]
STRENGTHS = ["Low", "Medium", "Strong", "Very Strong"]

# Practical default map grouping based on the user-provided map.
BUILDING_QUADRANT = {
    "Water Process 1": "NW",
    "Power Station": "NW",
    "Development Complex": "NW",
    "Water Process 2": "NE",
    "Treatment Plant 1": "NE",
    "Central Reservoir": "CENTER",
    "Treatment Plant 2": "SW",
    "Water Process 3": "SW",
    "Ammunition Factory": "SE",
    "Helipad": "SE",
    "Water Process 4": "SE",
}


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS raid_state (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                locked INTEGER NOT NULL DEFAULT 0,
                live_call TEXT
            );
            INSERT OR IGNORE INTO raid_state(id, locked) VALUES(1,0);

            CREATE TABLE IF NOT EXISTS players (
                user_id INTEGER PRIMARY KEY,
                display_name TEXT NOT NULL,
                available TEXT NOT NULL DEFAULT 'Yes',
                preferred_role TEXT NOT NULL DEFAULT 'No Preference',
                strength TEXT NOT NULL DEFAULT 'Medium',
                willing_reservist INTEGER NOT NULL DEFAULT 1,
                roster_status TEXT NOT NULL DEFAULT 'active',
                confirmed INTEGER NOT NULL DEFAULT 0,
                primary_building TEXT,
                secondary_building TEXT,
                quadrant TEXT,
                assigned_role TEXT,
                water_quadrant TEXT,
                final_phase TEXT DEFAULT 'Center Support',
                notes TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            """
        )


def is_leadership(member: discord.Member) -> bool:
    if member.guild_permissions.administrator or member.guild_permissions.manage_guild:
        return True
    return any(role.id in LEADERSHIP_ROLE_IDS for role in member.roles)


def get_player(user_id: int):
    with db() as con:
        return con.execute("SELECT * FROM players WHERE user_id=?", (user_id,)).fetchone()


def raid_locked() -> bool:
    with db() as con:
        return bool(con.execute("SELECT locked FROM raid_state WHERE id=1").fetchone()[0])


def count_status(status: str) -> int:
    with db() as con:
        return con.execute("SELECT COUNT(*) FROM players WHERE roster_status=?", (status,)).fetchone()[0]


def active_confirmed() -> int:
    with db() as con:
        return con.execute("SELECT COUNT(*) FROM players WHERE roster_status='active' AND confirmed=1").fetchone()[0]


def ordered_players(status: Optional[str] = None):
    with db() as con:
        if status:
            return con.execute(
                "SELECT * FROM players WHERE roster_status=? ORDER BY display_name COLLATE NOCASE", (status,)
            ).fetchall()
        return con.execute("SELECT * FROM players ORDER BY display_name COLLATE NOCASE").fetchall()


def upsert_signup(user: discord.abc.User, available: str, preferred_role: str, strength: str, willing: bool):
    existing = get_player(user.id)
    with db() as con:
        if existing:
            con.execute(
                """UPDATE players SET display_name=?, available=?, preferred_role=?, strength=?, willing_reservist=?, updated_at=CURRENT_TIMESTAMP WHERE user_id=?""",
                (user.display_name, available, preferred_role, strength, int(willing), user.id),
            )
        else:
            status = "active" if count_status("active") < MAX_ACTIVE else "reservist"
            con.execute(
                """INSERT INTO players(user_id, display_name, available, preferred_role, strength, willing_reservist, roster_status)
                   VALUES(?,?,?,?,?,?,?)""",
                (user.id, user.display_name, available, preferred_role, strength, int(willing), status),
            )


def player_orders_embed(row) -> discord.Embed:
    e = discord.Embed(title="OAO — YOUR RESERVOIR ORDERS")
    if not row:
        e.description = "You are not signed up yet. Press **Sign Up** on the main panel."
        return e
    status = "ACTIVE 30" if row["roster_status"] == "active" else "RESERVIST"
    e.add_field(name="Roster", value=status, inline=True)
    e.add_field(name="Confirmed", value="Yes" if row["confirmed"] else "No", inline=True)
    e.add_field(name="Role", value=row["assigned_role"] or row["preferred_role"], inline=True)
    e.add_field(name="Primary", value=row["primary_building"] or "Unassigned", inline=False)
    e.add_field(name="Secondary / Rotation", value=row["secondary_building"] or "Unassigned", inline=False)
    e.add_field(name="Quadrant", value=row["quadrant"] or "Unassigned", inline=True)
    e.add_field(name="Water Tank Duty", value=row["water_quadrant"] or "None", inline=True)
    e.add_field(name="Final Phase", value=row["final_phase"] or "Center Support", inline=False)
    if row["notes"]:
        e.add_field(name="Leadership Notes", value=row["notes"][:1000], inline=False)
    return e


class SignupModal(discord.ui.Modal, title="OAO Reservoir Signup"):
    availability = discord.ui.TextInput(label="Available?", placeholder="Yes or Maybe", default="Yes", max_length=10)
    preferred = discord.ui.TextInput(label="Preferred role", placeholder="Fighter / Defense / Fast Capper / Water Runner / Flex", required=False, max_length=40)
    strength = discord.ui.TextInput(label="Main march strength", placeholder="Low / Medium / Strong / Very Strong", default="Medium", max_length=20)
    reservist = discord.ui.TextInput(label="Willing to be a reservist?", placeholder="Yes or No", default="Yes", max_length=5)

    async def on_submit(self, interaction: discord.Interaction):
        if raid_locked() and not is_leadership(interaction.user):
            await interaction.response.send_message("The OAO Reservoir roster is currently locked.", ephemeral=True)
            return
        avail = str(self.availability).strip().title()
        pref_raw = str(self.preferred).strip() or "No Preference"
        pref = next((r for r in ROLES if r.lower() == pref_raw.lower()), pref_raw[:40])
        strength_raw = str(self.strength).strip().title()
        strength = strength_raw if strength_raw in STRENGTHS else "Medium"
        willing = str(self.reservist).strip().lower().startswith("y")
        upsert_signup(interaction.user, avail, pref, strength, willing)
        row = get_player(interaction.user.id)
        await interaction.response.send_message(
            f"Signup saved. You are currently **{row['roster_status'].upper()}**.", ephemeral=True
        )


class MainPanel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="SIGN UP", style=discord.ButtonStyle.success, custom_id="rr:signup")
    async def signup(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(SignupModal())

    @discord.ui.button(label="MY ORDERS", style=discord.ButtonStyle.primary, custom_id="rr:orders")
    async def orders(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=player_orders_embed(get_player(interaction.user.id)), ephemeral=True, view=OrdersView())

    @discord.ui.button(label="ROSTER", style=discord.ButtonStyle.secondary, custom_id="rr:roster")
    async def roster(self, interaction: discord.Interaction, button: discord.ui.Button):
        actives = ordered_players("active")
        reserves = ordered_players("reservist")
        e = discord.Embed(title="OAO RESERVOIR ROSTER")
        e.description = f"**Active:** {len(actives)}/{MAX_ACTIVE}  •  **Reservists:** {len(reserves)}/{MAX_RESERVISTS}  •  **Confirmed:** {active_confirmed()}/{len(actives)}"
        active_text = "\n".join(f"{'✅' if p['confirmed'] else '⬜'} {p['display_name']} — {p['primary_building'] or 'Unassigned'}" for p in actives[:30]) or "None"
        reserve_text = "\n".join(f"{i+1}. {p['display_name']} — {p['preferred_role']}" for i,p in enumerate(reserves[:10])) or "None"
        e.add_field(name="ACTIVE 30", value=active_text[:1024], inline=False)
        e.add_field(name="RESERVISTS", value=reserve_text[:1024], inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @discord.ui.button(label="BATTLE MAP", style=discord.ButtonStyle.secondary, custom_id="rr:map")
    async def battle_map(self, interaction: discord.Interaction, button: discord.ui.Button):
        f = discord.File(MAP_PATH, filename="oao_reservoir_map.png")
        e = discord.Embed(title="OAO RESERVOIR BATTLE MAP", description="Use **My Orders** for your exact building, quadrant, and Water Tank duty.")
        e.set_image(url="attachment://oao_reservoir_map.png")
        await interaction.response.send_message(embed=e, file=f, ephemeral=True)

    @discord.ui.button(label="WATER TEAMS", style=discord.ButtonStyle.secondary, custom_id="rr:waterteams")
    async def water_teams(self, interaction: discord.Interaction, button: discord.ui.Button):
        with db() as con:
            rows = con.execute("SELECT * FROM players WHERE roster_status='active' AND water_quadrant IS NOT NULL ORDER BY water_quadrant, display_name").fetchall()
        e = discord.Embed(title="OAO WATER TANK RUNNERS")
        for q in ["NW", "NE", "SW", "SE"]:
            names = [r["display_name"] for r in rows if r["water_quadrant"] == q]
            e.add_field(name=q, value="\n".join(names) if names else "Unassigned", inline=True)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @discord.ui.button(label="HELP", style=discord.ButtonStyle.secondary, custom_id="rr:help")
    async def help_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        text = (
            "**Members:** Sign Up → confirm → check My Orders before raid.\n"
            "**Active 30:** players currently in the raid.\n"
            "**Reservists:** official players outside the active 30 who can be promoted if needed.\n"
            "**Secondary assignment:** a tactical rotation target, not a reservist status.\n"
            "Use the Battle Map and follow live OAO calls during the raid."
        )
        await interaction.response.send_message(text, ephemeral=True)

    @discord.ui.button(label="COMMAND CENTER", style=discord.ButtonStyle.danger, custom_id="rr:command")
    async def command(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not isinstance(interaction.user, discord.Member) or not is_leadership(interaction.user):
            await interaction.response.send_message("Leadership only.", ephemeral=True)
            return
        await interaction.response.send_message(embed=command_center_embed(), view=LeadershipPanel(), ephemeral=True)


class OrdersView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)

    @discord.ui.button(label="CONFIRM", style=discord.ButtonStyle.success)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = get_player(interaction.user.id)
        if not row:
            await interaction.response.send_message("Sign up first.", ephemeral=True)
            return
        with db() as con:
            con.execute("UPDATE players SET confirmed=1, updated_at=CURRENT_TIMESTAMP WHERE user_id=?", (interaction.user.id,))
        await interaction.response.edit_message(embed=player_orders_embed(get_player(interaction.user.id)), view=self)

    @discord.ui.button(label="I CAN'T ATTEND", style=discord.ButtonStyle.danger)
    async def cant_attend(self, interaction: discord.Interaction, button: discord.ui.Button):
        with db() as con:
            con.execute("UPDATE players SET confirmed=0, available='No', updated_at=CURRENT_TIMESTAMP WHERE user_id=?", (interaction.user.id,))
        await interaction.response.edit_message(embed=player_orders_embed(get_player(interaction.user.id)), view=self)


class BuildingSelect(discord.ui.Select):
    def __init__(self, action: str):
        options = [discord.SelectOption(label=b, value=b) for b in BUILDINGS]
        super().__init__(placeholder=f"Choose building to {action.lower()}...", options=options, min_values=1, max_values=1)
        self.action = action

    async def callback(self, interaction: discord.Interaction):
        building = self.values[0]
        with db() as con:
            rows = con.execute("SELECT * FROM players WHERE primary_building=? OR secondary_building=? ORDER BY roster_status, display_name", (building, building)).fetchall()
        assigned = "\n".join(f"• {r['display_name']} — {r['assigned_role'] or r['preferred_role']} ({r['roster_status']})" for r in rows) or "No assigned players."
        if self.action == "VIEW":
            e = discord.Embed(title=building, description=assigned[:4000])
            await interaction.response.edit_message(embed=e, view=BuildingMenuView())
        else:
            await interaction.response.send_message(
                f"**OAO CALL — {self.action} {building.upper()}**\nAssigned team: move now. Other squads hold unless called.",
                allowed_mentions=discord.AllowedMentions.none(),
            )


class BuildingMenuView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        self.add_item(BuildingSelect("VIEW"))


class LiveActionSelect(discord.ui.Select):
    def __init__(self, action: str):
        options = [discord.SelectOption(label=b, value=b) for b in BUILDINGS]
        super().__init__(placeholder=f"{action}: choose target...", options=options)
        self.action = action

    async def callback(self, interaction: discord.Interaction):
        building = self.values[0]
        await interaction.response.send_message(
            f"**OAO LIVE CALL — {self.action.upper()} {building.upper()}**\nFollow assigned squads. Do not abandon other objectives unless leadership calls it.",
            allowed_mentions=discord.AllowedMentions.none(),
        )


class LiveView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=600)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return isinstance(interaction.user, discord.Member) and is_leadership(interaction.user)

    @discord.ui.button(label="PUSH", style=discord.ButtonStyle.danger)
    async def push(self, interaction, button):
        v = discord.ui.View(timeout=180); v.add_item(LiveActionSelect("PUSH"))
        await interaction.response.send_message("Choose push target:", view=v, ephemeral=True)

    @discord.ui.button(label="HOLD", style=discord.ButtonStyle.primary)
    async def hold(self, interaction, button):
        v = discord.ui.View(timeout=180); v.add_item(LiveActionSelect("HOLD"))
        await interaction.response.send_message("Choose hold target:", view=v, ephemeral=True)

    @discord.ui.button(label="REINFORCE", style=discord.ButtonStyle.primary)
    async def reinforce(self, interaction, button):
        v = discord.ui.View(timeout=180); v.add_item(LiveActionSelect("REINFORCE"))
        await interaction.response.send_message("Choose reinforce target:", view=v, ephemeral=True)

    @discord.ui.button(label="ROTATE", style=discord.ButtonStyle.secondary)
    async def rotate(self, interaction, button):
        v = discord.ui.View(timeout=180); v.add_item(LiveActionSelect("ROTATE"))
        await interaction.response.send_message("Choose rotation target:", view=v, ephemeral=True)

    @discord.ui.button(label="RALLY", style=discord.ButtonStyle.danger)
    async def rally(self, interaction, button):
        v = discord.ui.View(timeout=180); v.add_item(LiveActionSelect("RALLY"))
        await interaction.response.send_message("Choose rally target:", view=v, ephemeral=True)

    @discord.ui.button(label="PORT", style=discord.ButtonStyle.secondary)
    async def port(self, interaction, button):
        v = discord.ui.View(timeout=180); v.add_item(LiveActionSelect("PORT"))
        await interaction.response.send_message("Choose port target:", view=v, ephemeral=True)

    @discord.ui.button(label="WATER TANK", style=discord.ButtonStyle.success)
    async def water(self, interaction, button):
        await interaction.response.send_message("Choose Water Tank quadrant:", view=WaterCallView(), ephemeral=True)

    @discord.ui.button(label="ALL CENTER", style=discord.ButtonStyle.danger)
    async def all_center(self, interaction, button):
        await interaction.response.send_message("**OAO CALL — ALL CENTER**\nMain force to **Central Reservoir**. Leave only explicitly assigned hold teams behind.")

    @discord.ui.button(label="ABANDON", style=discord.ButtonStyle.secondary)
    async def abandon(self, interaction, button):
        v = discord.ui.View(timeout=180); v.add_item(LiveActionSelect("ABANDON"))
        await interaction.response.send_message("Choose objective to abandon:", view=v, ephemeral=True)


class WaterCallView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    async def call(self, interaction, q: str):
        with db() as con:
            rows = con.execute("SELECT * FROM players WHERE roster_status='active' AND water_quadrant=? ORDER BY strength DESC, display_name", (q,)).fetchall()
        runner = rows[0]["display_name"] if rows else "UNASSIGNED"
        secondary = rows[1]["display_name"] if len(rows) > 1 else "None"
        await interaction.response.send_message(f"**WATER TANK — {q}**\nRunner: **{runner}**\nSecondary runner: **{secondary}**\nEveryone else hold assignments.")

    @discord.ui.button(label="NW", style=discord.ButtonStyle.success)
    async def nw(self, interaction, button): await self.call(interaction, "NW")
    @discord.ui.button(label="NE", style=discord.ButtonStyle.success)
    async def ne(self, interaction, button): await self.call(interaction, "NE")
    @discord.ui.button(label="SW", style=discord.ButtonStyle.success)
    async def sw(self, interaction, button): await self.call(interaction, "SW")
    @discord.ui.button(label="SE", style=discord.ButtonStyle.success)
    async def se(self, interaction, button): await self.call(interaction, "SE")


def command_center_embed():
    a, r, c = count_status("active"), count_status("reservist"), active_confirmed()
    with db() as con:
        unassigned = con.execute("SELECT COUNT(*) FROM players WHERE roster_status='active' AND primary_building IS NULL").fetchone()[0]
    e = discord.Embed(title="OAO RR — COMMAND CENTER")
    e.description = f"**Active:** {a}/{MAX_ACTIVE}  •  **Reservists:** {r}/{MAX_RESERVISTS}\n**Confirmed:** {c}/{a}  •  **Unassigned:** {unassigned}\n**Roster:** {'LOCKED' if raid_locked() else 'OPEN'}"
    return e


def auto_assign_players():
    """Simple safe optimizer: every active gets a primary objective, role, quadrant, and selected mobile players get water duty.

    This is intentionally editable and does not pretend raw power alone is optimal.
    """
    strength_rank = {"Very Strong": 4, "Strong": 3, "Medium": 2, "Low": 1}
    players = ordered_players("active")
    if not players:
        return 0

    # Sort by strength but keep preference useful.
    p_sorted = sorted(players, key=lambda p: (-strength_rank.get(p["strength"], 2), p["display_name"].lower()))
    building_cycle = [
        "Central Reservoir",
        "Power Station", "Helipad",
        "Development Complex", "Ammunition Factory",
        "Treatment Plant 1", "Treatment Plant 2",
        "Water Process 1", "Water Process 2", "Water Process 3", "Water Process 4",
    ]

    with db() as con:
        for i, p in enumerate(p_sorted):
            primary = building_cycle[i % len(building_cycle)]
            secondary = building_cycle[(i + 3) % len(building_cycle)]
            q = BUILDING_QUADRANT[primary]
            pref = p["preferred_role"]
            if pref and pref != "No Preference":
                role = pref
            elif strength_rank.get(p["strength"], 2) >= 4:
                role = "Rally Anchor"
            elif i % 5 == 0:
                role = "Fast Capper"
            else:
                role = "Support"
            con.execute(
                """UPDATE players SET primary_building=?, secondary_building=?, quadrant=?, assigned_role=?, water_quadrant=NULL, updated_at=CURRENT_TIMESTAMP WHERE user_id=?""",
                (primary, secondary, q, role, p["user_id"]),
            )

        # Dedicated water runners: prefer those who asked for Water Runner/Flex/Fast Capper, otherwise use later non-center players.
        refreshed = con.execute("SELECT * FROM players WHERE roster_status='active'").fetchall()
        candidates = sorted(
            refreshed,
            key=lambda p: (
                0 if p["preferred_role"] == "Water Runner" else 1 if p["preferred_role"] in ("Flex", "Fast Capper") else 2,
                strength_rank.get(p["strength"], 2),
                p["display_name"].lower(),
            ),
        )
        for q, p in zip(["NW", "NE", "SW", "SE"], candidates[:4]):
            con.execute("UPDATE players SET water_quadrant=? WHERE user_id=?", (q, p["user_id"]))
    return len(players)


class LeadershipPanel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=600)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not isinstance(interaction.user, discord.Member) or not is_leadership(interaction.user):
            await interaction.response.send_message("Leadership only.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="AUTO ASSIGN", style=discord.ButtonStyle.success)
    async def auto_assign(self, interaction, button):
        n = auto_assign_players()
        await interaction.response.edit_message(embed=command_center_embed(), view=self)
        await interaction.followup.send(f"Assigned {n} active players. Review and edit before posting orders.", ephemeral=True)

    @discord.ui.button(label="BUILDINGS", style=discord.ButtonStyle.primary)
    async def buildings(self, interaction, button):
        await interaction.response.send_message("Choose a building:", view=BuildingMenuView(), ephemeral=True)

    @discord.ui.button(label="WATER RUNNERS", style=discord.ButtonStyle.primary)
    async def water_runners(self, interaction, button):
        await MainPanel().water_teams.callback(interaction)  # re-use output

    @discord.ui.button(label="LIVE MODE", style=discord.ButtonStyle.danger)
    async def live_mode(self, interaction, button):
        await interaction.response.send_message("**OAO LIVE COMMAND MODE**", view=LiveView(), ephemeral=True)

    @discord.ui.button(label="LOCK / UNLOCK", style=discord.ButtonStyle.secondary)
    async def lock_toggle(self, interaction, button):
        locked = raid_locked()
        with db() as con:
            con.execute("UPDATE raid_state SET locked=? WHERE id=1", (0 if locked else 1,))
        await interaction.response.edit_message(embed=command_center_embed(), view=self)

    @discord.ui.button(label="POST ROSTER", style=discord.ButtonStyle.secondary)
    async def post_roster(self, interaction, button):
        actives = ordered_players("active")
        reserves = ordered_players("reservist")
        lines = ["**OAO RESERVOIR RAID — ACTIVE 30**"]
        for i,p in enumerate(actives,1):
            lines.append(f"{i}. {p['display_name']} — {p['primary_building'] or 'Unassigned'} — {p['assigned_role'] or p['preferred_role']}")
        lines.append("\n**RESERVISTS**")
        for i,p in enumerate(reserves,1):
            lines.append(f"R{i}. {p['display_name']} — {p['preferred_role']}")
        text = "\n".join(lines)
        await interaction.response.send_message(text[:2000])

    @discord.ui.button(label="RESET RAID", style=discord.ButtonStyle.danger)
    async def reset(self, interaction, button):
        await interaction.response.send_message("This clears the current raid roster and assignments. Confirm?", view=ResetConfirmView(), ephemeral=True)


class ResetConfirmView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)

    @discord.ui.button(label="YES, RESET", style=discord.ButtonStyle.danger)
    async def yes(self, interaction, button):
        if not isinstance(interaction.user, discord.Member) or not is_leadership(interaction.user):
            await interaction.response.send_message("Leadership only.", ephemeral=True)
            return
        with db() as con:
            con.execute("DELETE FROM players")
            con.execute("UPDATE raid_state SET locked=0, live_call=NULL WHERE id=1")
        await interaction.response.edit_message(content="Raid reset complete.", view=None)

    @discord.ui.button(label="CANCEL", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction, button):
        await interaction.response.edit_message(content="Reset cancelled.", view=None)


class OAOReservoirBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        init_db()
        self.add_view(MainPanel())
        if GUILD_ID:
            guild = discord.Object(id=GUILD_ID)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
        else:
            await self.tree.sync()


bot = OAOReservoirBot()


@bot.tree.command(name="rr", description="Open the OAO Reservoir Raid command panel")
async def rr(interaction: discord.Interaction):
    a = count_status("active")
    r = count_status("reservist")
    c = active_confirmed()
    row = get_player(interaction.user.id)
    e = discord.Embed(title="OAO RESERVOIR RAID")
    e.description = f"**Active:** {a}/{MAX_ACTIVE}  •  **Reservists:** {r}/{MAX_RESERVISTS}  •  **Confirmed:** {c}/{a}\n\nUse the buttons below."
    if row:
        e.add_field(name="Your Status", value="Confirmed" if row["confirmed"] else "Not Confirmed", inline=True)
        e.add_field(name="Your Assignment", value=row["primary_building"] or "Unassigned", inline=True)
    else:
        e.add_field(name="Your Status", value="Not signed up", inline=True)
    e.set_footer(text="One and Only • Reservoir Command")
    await interaction.response.send_message(embed=e, view=MainPanel())


@bot.tree.command(name="rr_assign", description="Leadership: assign a player's building and role")
@app_commands.describe(member="OAO member", primary="Primary building", secondary="Secondary/rotation building", role="Assigned role", water_quadrant="Optional Water Tank quadrant")
@app_commands.choices(
    primary=[app_commands.Choice(name=b, value=b) for b in BUILDINGS],
    secondary=[app_commands.Choice(name=b, value=b) for b in BUILDINGS],
    role=[app_commands.Choice(name=r, value=r) for r in ROLES[:-1]],
    water_quadrant=[app_commands.Choice(name=q, value=q) for q in ["NW", "NE", "SW", "SE"]],
)
async def rr_assign(interaction: discord.Interaction, member: discord.Member, primary: app_commands.Choice[str], secondary: Optional[app_commands.Choice[str]] = None, role: Optional[app_commands.Choice[str]] = None, water_quadrant: Optional[app_commands.Choice[str]] = None):
    if not is_leadership(interaction.user):
        await interaction.response.send_message("Leadership only.", ephemeral=True); return
    row = get_player(member.id)
    if not row:
        upsert_signup(member, "Yes", "No Preference", "Medium", True)
    sec = secondary.value if secondary else None
    assigned_role = role.value if role else None
    water = water_quadrant.value if water_quadrant else None
    with db() as con:
        con.execute("UPDATE players SET primary_building=?, secondary_building=?, quadrant=?, assigned_role=?, water_quadrant=?, updated_at=CURRENT_TIMESTAMP WHERE user_id=?", (primary.value, sec, BUILDING_QUADRANT[primary.value], assigned_role, water, member.id))
    await interaction.response.send_message(f"Updated **{member.display_name}** → **{primary.value}**.", ephemeral=True)


@bot.tree.command(name="rr_reservist", description="Leadership: move a player to the Reservoir reservist roster")
async def rr_reservist(interaction: discord.Interaction, member: discord.Member):
    if not is_leadership(interaction.user):
        await interaction.response.send_message("Leadership only.", ephemeral=True); return
    if count_status("reservist") >= MAX_RESERVISTS:
        await interaction.response.send_message("Reservist roster is already 10/10.", ephemeral=True); return
    if not get_player(member.id):
        upsert_signup(member, "Yes", "No Preference", "Medium", True)
    with db() as con:
        con.execute("UPDATE players SET roster_status='reservist', confirmed=0, updated_at=CURRENT_TIMESTAMP WHERE user_id=?", (member.id,))
    await interaction.response.send_message(f"{member.display_name} moved to **Reservists**.", ephemeral=True)


@bot.tree.command(name="rr_promote", description="Leadership: promote a reservist into the active 30")
async def rr_promote(interaction: discord.Interaction, member: discord.Member):
    if not is_leadership(interaction.user):
        await interaction.response.send_message("Leadership only.", ephemeral=True); return
    if count_status("active") >= MAX_ACTIVE:
        await interaction.response.send_message("Active roster is already 30/30. Use /rr_replace instead.", ephemeral=True); return
    row = get_player(member.id)
    if not row or row["roster_status"] != "reservist":
        await interaction.response.send_message("That player is not currently a reservist.", ephemeral=True); return
    with db() as con:
        con.execute("UPDATE players SET roster_status='active', updated_at=CURRENT_TIMESTAMP WHERE user_id=?", (member.id,))
    await interaction.response.send_message(f"{member.display_name} promoted to **Active**.", ephemeral=True)


@bot.tree.command(name="rr_replace", description="Leadership: replace an active player with a reservist and transfer assignments")
async def rr_replace(interaction: discord.Interaction, active: discord.Member, reservist: discord.Member):
    if not is_leadership(interaction.user):
        await interaction.response.send_message("Leadership only.", ephemeral=True); return
    a = get_player(active.id); r = get_player(reservist.id)
    if not a or a["roster_status"] != "active" or not r or r["roster_status"] != "reservist":
        await interaction.response.send_message("Select one active player and one current reservist.", ephemeral=True); return
    with db() as con:
        con.execute("UPDATE players SET roster_status='reservist', confirmed=0 WHERE user_id=?", (active.id,))
        con.execute(
            """UPDATE players SET roster_status='active', primary_building=?, secondary_building=?, quadrant=?, assigned_role=?, water_quadrant=?, final_phase=?, confirmed=0 WHERE user_id=?""",
            (a["primary_building"], a["secondary_building"], a["quadrant"], a["assigned_role"], a["water_quadrant"], a["final_phase"], reservist.id),
        )
    await interaction.response.send_message(f"**{reservist.display_name}** promoted and inherited **{active.display_name}'s** raid assignment.")


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} ({bot.user.id})")


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("DISCORD_TOKEN is missing. Copy .env.example to .env and add your bot token.")
    bot.run(TOKEN)
