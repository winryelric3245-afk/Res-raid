# OAO Reservoir Raid Bot

A Discord bot built specifically for OAO Reservoir Raid organization in Tiles Survive.

## What it does

- Button-first member signup and confirmation
- Active roster capped at 30
- Reservists tracked separately
- Exact building assignments for the Reservoir map
- Water Tank runner assignments by quadrant
- Individual "My Orders" cards
- Leadership command center
- Live push / hold / reinforce / rotate / rally / port / water / all-center / abandon calls
- Automatic assignment helper using role preferences and strength bands
- SQLite persistence across restarts
- Uses the included Reservoir map image

## Exact map objectives

- Water Process 1
- Water Process 2
- Water Process 3
- Water Process 4
- Power Station
- Development Complex
- Treatment Plant 1
- Treatment Plant 2
- Ammunition Factory
- Helipad
- Central Reservoir

## Setup

1. Create a Discord application and bot in the Discord Developer Portal.
2. Enable Server Members Intent if you want richer member handling.
3. Invite the bot with the `bot` and `applications.commands` scopes.
4. Copy `.env.example` to `.env`.
5. Fill in your bot token, server ID, and OAO leadership role IDs.
6. Install dependencies:

```bash
pip install -r requirements.txt
```

7. Run:

```bash
python bot.py
```

## Main user flow

Run `/rr` once. Members use buttons for:

- Sign Up
- My Orders
- Roster
- Battle Map
- Water Teams
- Help

Leadership sees an additional Command Center button.

## Leadership tools

The leadership command center provides:

- Auto Assign
- Edit Player
- Buildings
- Water Runners
- Replace Player
- Live Mode
- Post Roster
- Lock / Unlock Raid
- Reset Raid

## Notes

- "Reservists" always means players outside the active 30.
- A player's secondary assignment is tactical and does not mean they are a reservist.
- Building values and exact tactical priorities can change with game updates, so assignments are editable rather than hard-coded as immutable strategy.
- Never hard-code your Discord bot token in this project. Keep it in `.env` only.
